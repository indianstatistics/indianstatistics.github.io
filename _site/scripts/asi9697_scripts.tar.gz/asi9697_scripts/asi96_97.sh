# Copyright 2012 Centre for Economic Studies and Planning (CESP)
#
# This script was written by Abdul Raheem Shariq (shariqazeez at
# gmail dot com) as part of an initiative directed by Vikas Rawal
# (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
# and ASI data. This initiative is supported by the CAS programme of
# CESP.
# 
# To run this, you need to specify below the ip address/hostname of
# the mysql server, the mysql username and mysql password.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#! /bin/sh
server=127.0.0.1 # ip address/hostname of the mysql server 
username="USERNAME"   # mysql user name
pass="PASSWORD"    # password of the mysql user
time_start=`date +%s`
echo "Scripts to read ASI 1996-97 data called at `date`"
rm -Rf ../csv432mnbv
mkdir ../csv432mnbv
./asi9697.awk ../Data/ASI96_97.TXT
echo "Data parsed into csv files for each level at `date`"
mysql --host=$server --user=$username --password=$pass < asi9697.sql
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC011.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC040.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC040_SRC014.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC051.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC053.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC052.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC054.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC071.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC072.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC073.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC074.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC081.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC082.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC091.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC101.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC102.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC111.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC121.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC131.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC132.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC133.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC141.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_96_97 --local ../csv432mnbv/RC142.csv
echo "Mysql database created at `date`"
echo "Now cleaning up..."
rm -Rf ../csv432mnbv
time_end=`date +%s`
time_exec=`expr $(( $time_end - $time_start ))`
echo "The script took $time_exec seconds to finish."
