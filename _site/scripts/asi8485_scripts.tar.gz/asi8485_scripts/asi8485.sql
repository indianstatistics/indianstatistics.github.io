-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Sakshi Jain (jainsakshi2016 at gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program. If not, see <http://www.gnu.org/licenses/>.

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


--
-- Database: `ASI_84_85`
--
DROP DATABASE IF EXISTS ASI_84_85;
CREATE DATABASE ASI_84_85;
USE ASI_84_85;


-- --------------------------------------------------------

--
-- Table structure for table `RC011`
--

CREATE TABLE IF NOT EXISTS `RC011` (
  `Industry` varchar(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Block` int(2) NOT NULL,
  `Scheme` int(1) NOT NULL,
  `F.Srl.No.` int(5) NOT NULL,
  `PSRl_No.` varchar(5) NOT NULL,
  `Location_(Code)` int(1) NOT NULL,
  `Area_(Code)` int(1) NOT NULL,
  `Year_of_initial_Production` int(4) NOT NULL,
  `organisation` int(1) NOT NULL,
  `Ownership` int(1) NOT NULL,
  `Equity_Capital_Public` int(3) NOT NULL,
  `Equity_Capital_Private` int(3) NOT NULL,
  `Management` int(1) NOT NULL,
  `Whether_ancillary` int(1) NOT NULL,
  `Whether_registered` int(1) NOT NULL,
  `Power_used` int(1) NOT NULL,
  `Open/Closed` int(1) NOT NULL COMMENT 'Open-0,Closed-1',
  `No._of_factories` int(2) NOT NULL,
  `Accounting_Year` int(4) NOT NULL,
  `Account_Closing` int(6) NOT NULL COMMENT 'ddmmyy',
  `Gross_value_of_P_&_M` int(8) NOT NULL,
  `Working_days_manufacturing` int(3) NOT NULL,
  `Working_days_repair_&_maintenance` int(3) NOT NULL,
  `Working_days_total` int(3) NOT NULL,
  `Total_no_of_shifts` int(4) NOT NULL,
  `Shifts_Per_day` int(2) NOT NULL,
  `Length_of_shifts` int(2) NOT NULL,
  `No_of_Records_block4` int(1) NOT NULL,
  `No_of_Records_block5` int(1) NOT NULL,
  `No_of_Records_block6` int(1) NOT NULL,
  `No_of_Records_block8` int(1) NOT NULL,
  `No_of_Records_block9` int(1) NOT NULL,
  `No_of_Records_block10` int(1) NOT NULL,
  `No_of_Records_block11` int(1) NOT NULL,
  `No_of_Records_block12` int(1) NOT NULL,
  `Sub_Total` int(2) NOT NULL,
  `No_of_Records_block13` int(2) NOT NULL,
  `No_of_Records_block13A_&_B` int(2) NOT NULL,
  `No_of_Records_block14` int(2) NOT NULL,
  `No_of_Records_block14A` int(2) NOT NULL,
  `other` int(1) NOT NULL,
  `S_Total` int(2) NOT NULL,
  `Total` int(3) NOT NULL,
  `Filler` varchar(4) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC041`
--

CREATE TABLE IF NOT EXISTS `RC041` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Land';

-- --------------------------------------------------------

--
-- Table structure for table `RC042`
--

CREATE TABLE IF NOT EXISTS `RC042` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total(3to5)` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Improvement to land etc.';

-- --------------------------------------------------------

--
-- Table structure for table `RC043`
--

CREATE TABLE IF NOT EXISTS `RC043` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Building';

-- --------------------------------------------------------

--
-- Table structure for table `RC044`
--

CREATE TABLE IF NOT EXISTS `RC044` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Plant and machinery';

-- --------------------------------------------------------

--
-- Table structure for table `RC045`
--

CREATE TABLE IF NOT EXISTS `RC045` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Transport equipment';

-- --------------------------------------------------------

--
-- Table structure for table `RC046`
--

CREATE TABLE IF NOT EXISTS `RC046` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Tools etc';

-- --------------------------------------------------------

--
-- Table structure for table `RC047`
--

CREATE TABLE IF NOT EXISTS `RC047` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Assets under const.';

-- --------------------------------------------------------

--
-- Table structure for table `RC048`
--

CREATE TABLE IF NOT EXISTS `RC048` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Net_opening_balance` int(11) NOT NULL,
  `New` int(11) NOT NULL,
  `Used` int(11) NOT NULL,
  `Own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL COMMENT 'Sum of columns "Net_opening_balance","New" and "Used"',
  `Sold_or_Discarded` int(11) NOT NULL,
  `Depreciation` int(11) NOT NULL,
  `Net_closing_balance` int(11) NOT NULL,
  `Rent_Paid` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Total';

-- --------------------------------------------------------

--
-- Table structure for table `RC051`
--

CREATE TABLE IF NOT EXISTS `RC051` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Materials` int(11) NOT NULL,
  `Fuels` int(11) NOT NULL,
  `Stores_etc` int(11) NOT NULL,
  `Semi_finished_goods` int(11) NOT NULL,
  `Products_&_by_Products` int(11) NOT NULL,
  `Cash_in_hand` int(11) NOT NULL,
  `Amounts_receivable` int(11) NOT NULL,
  `Amounts_payable` int(11) NOT NULL,
  `Total_(7-8+11)` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Opening balance';

-- --------------------------------------------------------

--
-- Table structure for table `RC052`
--

CREATE TABLE IF NOT EXISTS `RC052` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Materials` int(11) NOT NULL,
  `Fuels` int(11) NOT NULL,
  `Stores_etc` int(11) NOT NULL,
  `Semi_finished_goods` int(11) NOT NULL,
  `Products_&_by_products` int(11) NOT NULL,
  `Cash_in_hand` int(11) NOT NULL,
  `Amounts_receivable` int(11) NOT NULL,
  `Amounts_payable` int(11) NOT NULL,
  `Total_(7-8+11)` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Closing balance';

-- --------------------------------------------------------

--
-- Table structure for table `RC061`
--

CREATE TABLE IF NOT EXISTS `RC061` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Borrowing_from_term` int(11) NOT NULL,
  `Public_sector_banks` int(11) NOT NULL,
  `Co_operative_banks` int(11) NOT NULL,
  `Other_banks` int(11) NOT NULL,
  `Government` int(11) NOT NULL,
  `Others` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler_1` int(11) NOT NULL,
  `Filler_2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Opening balance(column 2)';

-- --------------------------------------------------------

--
-- Table structure for table `RC062`
--

CREATE TABLE IF NOT EXISTS `RC062` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Borrowing_from_term` int(11) NOT NULL,
  `Public_sector_banks` int(11) NOT NULL,
  `Co_operative_banks` int(11) NOT NULL,
  `Other_banks` int(11) NOT NULL,
  `Government` int(11) NOT NULL,
  `Others` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler_1` int(11) NOT NULL,
  `Filler_2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Closing balance(column 3)';

-- --------------------------------------------------------

--
-- Table structure for table `RC081`
--

CREATE TABLE IF NOT EXISTS `RC081` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Sub_total` int(11) NOT NULL,
  `Through_contractor` int(11) NOT NULL,
  `Total1` int(11) NOT NULL,
  `Supervisory_&_Manag.` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Manufacturing(column 2 )';

-- --------------------------------------------------------

--
-- Table structure for table `RC082`
--

CREATE TABLE IF NOT EXISTS `RC082` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Sub_total` int(11) NOT NULL,
  `Through_contractor` int(11) NOT NULL,
  `Total1` int(11) NOT NULL,
  `Supervisory_&_Manag` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Non-manufacturing(column 3)';

-- --------------------------------------------------------

--
-- Table structure for table `RC083`
--

CREATE TABLE IF NOT EXISTS `RC083` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Sub_total` int(11) NOT NULL,
  `Through_contractor` int(11) NOT NULL,
  `Total1` int(11) NOT NULL,
  `Supervisory_&_Manag.` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Total  ( Column 4)';

-- --------------------------------------------------------

--
-- Table structure for table `RC084`
--

CREATE TABLE IF NOT EXISTS `RC084` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Sub_total` int(11) NOT NULL,
  `Through_contractor` int(11) NOT NULL,
  `Total1` int(11) NOT NULL,
  `Supervisory_&_Manag` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Salaries wages etc.(column 6)';

-- --------------------------------------------------------

--
-- Table structure for table `RC085`
--

CREATE TABLE IF NOT EXISTS `RC085` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Sub_total` int(11) NOT NULL,
  `Through_contractor` int(11) NOT NULL,
  `Total1` int(11) NOT NULL,
  `Supervisory_&_Manag` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Bonus(column 7)';

-- --------------------------------------------------------

--
-- Table structure for table `RC086`
--

CREATE TABLE IF NOT EXISTS `RC086` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Men` int(7) NOT NULL,
  `Women` int(7) NOT NULL,
  `Children` int(7) NOT NULL,
  `Total1` int(7) NOT NULL,
  `Through_contractors` int(7) NOT NULL,
  `Total2` int(7) NOT NULL,
  `Supervisory_&_Manag.` int(7) NOT NULL,
  `Othr_employees` int(7) NOT NULL,
  `Total3` int(7) NOT NULL,
  `Working_proprietor` int(7) NOT NULL,
  `Unpaid_family_workers` int(7) NOT NULL,
  `If_co_operative` int(7) NOT NULL,
  `Other_employees` int(7) NOT NULL,
  `Total4` int(7) NOT NULL,
  `Filler` int(8) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC087`
--

CREATE TABLE IF NOT EXISTS `RC087` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Imputed_value_statutory` int(11) NOT NULL,
  `Imputed_value_non_statutory` int(11) NOT NULL,
  `Imputed_value_total` int(11) NOT NULL,
  `Employers_contribution_to_old_age_statutory` int(11) NOT NULL,
  `Employers_contribution_to_old_age_non_statutory` int(11) NOT NULL,
  `Employers_contribution_to_old_age_total` int(11) NOT NULL,
  `Employers_contribution_to_others_statutory` int(11) NOT NULL,
  `Employers_contribution_to_others_non_statutory` int(11) NOT NULL,
  `Employers_contribution_to_others_total` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC088`
--

CREATE TABLE IF NOT EXISTS `RC088` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Expenditure_statutory` int(11) NOT NULL,
  `Expenditure_non_statutory` int(11) NOT NULL,
  `Expenditure_total` int(11) NOT NULL,
  `Other_groups_benefit_statutory` int(11) NOT NULL,
  `Other_group_benefit_non_statutory` int(11) NOT NULL,
  `Other_group_benefit_total` int(11) NOT NULL,
  `Filler_1` int(11) NOT NULL,
  `Filler_2` int(11) NOT NULL,
  `Total1` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC091`
--

CREATE TABLE IF NOT EXISTS `RC091` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Link_Code_1` int(3) NOT NULL,
  `Item_code_1` int(4) NOT NULL,
  `Qty_1` int(10) NOT NULL,
  `Value_1` int(10) NOT NULL,
  `Item_Code_2` int(4) NOT NULL,
  `Qty_2` int(10) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` int(4) NOT NULL,
  `Qty_3` int(10) NOT NULL,
  `Value_3` int(10) NOT NULL,
  `Item_code_4` int(4) NOT NULL,
  `Qty_4` int(10) NOT NULL,
  `Value_4` int(10) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fuels electricity etc. consumed';

-- --------------------------------------------------------

--
-- Table structure for table `RC101`
--

CREATE TABLE IF NOT EXISTS `RC101` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Building` int(11) NOT NULL,
  `Machinery` int(11) NOT NULL,
  `Other_fixed_assets` int(11) NOT NULL,
  `Sub_total` int(11) NOT NULL,
  `Wages_to_Home_workers` int(11) NOT NULL,
  `cost_of_contract_&_Commission_work_done_by_others` int(11) NOT NULL,
  `Total_(4+5)_(8+10)` int(11) NOT NULL,
  `Purchase_value` int(11) NOT NULL,
  `Filler` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC111`
--

CREATE TABLE IF NOT EXISTS `RC111` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Postage_telephone_charges` int(11) NOT NULL,
  `Audit_A/c_fees_etc` int(11) NOT NULL,
  `Insurance` int(11) NOT NULL,
  `Advertising` int(11) NOT NULL,
  `Legal_charges_etc` int(11) NOT NULL,
  `Inward_transport_etc.` int(11) NOT NULL,
  `Purchase_agency_charges` int(11) NOT NULL,
  `Taxes_and_duties` int(11) NOT NULL,
  `Local_rates_etc` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC112`
--

CREATE TABLE IF NOT EXISTS `RC112` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Office_supplies` int(11) NOT NULL,
  `Others` int(11) NOT NULL,
  `S_total` int(11) NOT NULL,
  `Rent_other_than_payment_for_use_of_land` int(11) NOT NULL,
  `Interest` int(11) NOT NULL,
  `Sub_total` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Gross_value_of_products_to_be_stored_&_computed_through` int(11) NOT NULL,
  `Total_Material_consumed` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC121`
--

CREATE TABLE IF NOT EXISTS `RC121` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Work_done_for_others` int(11) NOT NULL,
  `Net_balance_of_goods` int(11) NOT NULL,
  `Non_Industrial_services` int(11) NOT NULL,
  `Sub_Total` int(11) NOT NULL,
  `Electricity_consumed_by_the_factory` int(11) NOT NULL,
  `Electricity_sold` int(11) NOT NULL,
  `Value_of_electricity_sold` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Sale_value_of_goods_etc` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC131`
--

CREATE TABLE IF NOT EXISTS `RC131` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Link_Code_1` int(3) NOT NULL,
  `Item_code_1` int(4) NOT NULL,
  `Qty_1` int(10) NOT NULL,
  `Value_1` int(10) NOT NULL,
  `Item_Code_2` int(4) NOT NULL,
  `Qty_2` int(10) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` int(4) NOT NULL,
  `Qty_3` int(10) NOT NULL,
  `Value_3` int(10) NOT NULL,
  `Item_code_4` int(4) NOT NULL,
  `Qty_4` int(10) NOT NULL,
  `Value_4` int(10) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Materials etc. consumed';

-- --------------------------------------------------------

--
-- Table structure for table `RC132`
--

CREATE TABLE IF NOT EXISTS `RC132` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Class_of_record` int(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Item_code_1` int(4) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Qty` int(11) NOT NULL,
  `Value` int(11) NOT NULL,
  `Item_Code_2` int(4) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC133`
--

CREATE TABLE IF NOT EXISTS `RC133` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code_1` int(3) NOT NULL,
  `Item_code_1` int(4) NOT NULL,
  `Qty_1` int(10) NOT NULL,
  `Value_1` int(10) NOT NULL,
  `Item_Code_2` int(4) NOT NULL,
  `Qty_2` int(10) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` int(4) NOT NULL,
  `Qty_3` int(10) NOT NULL,
  `Value_3` int(10) NOT NULL,
  `Item_code_4` int(4) NOT NULL,
  `Qty_4` int(10) NOT NULL,
  `Value_4` int(10) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Imported materials etc.(13B)';

-- --------------------------------------------------------

--
-- Table structure for table `RC141`
--

CREATE TABLE IF NOT EXISTS `RC141` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Item_code_1` int(4) NOT NULL,
  `Quantity_manufactured` int(11) NOT NULL,
  `Quantity_sold` int(11) NOT NULL,
  `Gross_sale_value` int(11) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sales_tax` int(11) NOT NULL,
  `Filler_1_(Calculated_value_of_qty_mfd.)` int(11) NOT NULL,
  `Filler_2` int(11) NOT NULL,
  `Filler_3` int(11) NOT NULL,
  `Filler` int(4) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC142`
--

CREATE TABLE IF NOT EXISTS `RC142` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sales_tax` int(11) NOT NULL,
  `Transport_charges` int(11) NOT NULL,
  `Commission_ agents` int(11) NOT NULL,
  `Rebates` int(11) NOT NULL,
  `Others` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler_1` int(11) NOT NULL,
  `Filler_2` int(11) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC143`
--

CREATE TABLE IF NOT EXISTS `RC143` (
  `Industry` int(4) NOT NULL,
  `State` int(2) NOT NULL,
  `Running_Sl_No` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code_1` int(3) NOT NULL,
  `Item_code_1` int(4) NOT NULL,
  `Qty_1` int(10) NOT NULL,
  `Value_1` int(10) NOT NULL,
  `Item_Code_2` int(4) NOT NULL,
  `Qty_2` int(10) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` int(4) NOT NULL,
  `Qty_3` int(10) NOT NULL,
  `Value_3` int(10) NOT NULL,
  `Item_code_4` int(4) NOT NULL,
  `Qty_4` int(10) NOT NULL,
  `Value_4` int(10) NOT NULL,
  `Update_Code` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Production of year';
