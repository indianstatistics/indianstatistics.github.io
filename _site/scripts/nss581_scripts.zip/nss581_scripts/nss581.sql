-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `NSS_58_1`
--

DROP DATABASE IF EXISTS NSS_58_1;
CREATE DATABASE NSS_58_1;
USE NSS_58_1;

-- --------------------------------------------------------

--
-- Table structure for table `Item_Level`
--

CREATE TABLE IF NOT EXISTS `Item_Level` (
  `ID` varchar(2) NOT NULL COMMENT 'W2',
  `Round_schedule` int(4) NOT NULL COMMENT '5810',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL COMMENT 'First 2 numbers represent the state code and the third number represents the region code',
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample_Posted` int(1) NOT NULL,
  `FSU` int(5) NOT NULL,
  `Segment` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `Household_number` varchar(2) NOT NULL,
  `Survey_code` int(1) NOT NULL COMMENT 'Household Surveyed: Original-1, Substitute-2, Casualty-3',
  `Reason_for_substitution_of_original_household` int(1) NOT NULL COMMENT 'Informant busy-1, members away from home-2, informant non-cooperative-3, others-9',
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `Mult_SS` int(10) NOT NULL,
  `Household_size` int(2) NOT NULL,
  `MPCE` int(8) NOT NULL,
  `MPCE_code` varchar(2) NOT NULL,
  `CMPCE_code` varchar(2) NOT NULL,
  `Household_type` int(1) NOT NULL COMMENT 'For rural areas: self-employed in non-agriculture-1, agricultural labour-2, other labour-3, self-employed  in agriculture-4, others-9. For urban areas: self-employed-1, regular wage/salary earning-2, casual labour-3, others-9',
  `Religion_Code` int(1) NOT NULL COMMENT 'Hinduism-1, Islam-2, Christianity-3, Sikhism-4, Jainism-5, Buddhism-6, Zoroastrianism-7, Others-9',
  `Social_group` int(1) NOT NULL COMMENT 'Scheduled Tribe-1, Scheduled Caste-2, Other Backward Class-3, Others-9',
  `Land_possessed` int(8) NOT NULL,
  `Dwelling_code` int(1) NOT NULL COMMENT 'owned-1, hired-2, no dwelling unit-3, others-9',
  `Type_dwelling` int(1) NOT NULL COMMENT 'independent house-1, flat-2, others-9',
  `Type_structure` int(1) NOT NULL COMMENT 'katcha-1, semi-pucca-2, pucca-3',
  `Covered_area` int(6) NOT NULL,
  `Cooking_code` varchar(2) NOT NULL COMMENT 'coke, coal-01, firewood and chips-02, LPG-03, gobar gas-04, dung cake-05, charcoal-06, kerosene-07, electricity-08, others-99, no cooking arrangement-10',
  `Lighting_code` int(1) NOT NULL COMMENT 'kerosene-1, other oil-2, gas-3, candle-4, electricity-5, others-9, no lighting arrangement-6',
  `Meals_taken_outside` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Ceremony_performed` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `PDS_purchase` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Time_Canvass` int(3) NOT NULL,
  `Item_Code` varchar(3) NOT NULL,
  `Filler/First_Hand_Value` int(8) NOT NULL,
  `Quantity_or_Filler_or_Second_Hand_Value` int(8) NOT NULL,
  `Value_or_Filler_or_Total_Value` int(8) NOT NULL,
  `Food_Code` int(1) NOT NULL,
  `On_use_of_durable` int(3) NOT NULL,
  `State_Group_Code` varchar(2) NOT NULL,
  `Lot` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Person_Level`
--

CREATE TABLE IF NOT EXISTS `Person_Level` (
  `ID` varchar(2) NOT NULL COMMENT 'W1',
  `Round_schedule` int(4) NOT NULL COMMENT '5810',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FSU` int(5) NOT NULL,
  `Segment` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `Household_number` varchar(2) NOT NULL,
  `Survey_code` int(1) NOT NULL COMMENT 'Household Surveyed: Original-1, Substitute-2, Casualty-3',
  `Reason_for_substitution_of_original_household` int(1) NOT NULL COMMENT 'informant busy-1, members away from home-2, informant non-cooperative-3, others-9',
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `Mult_SS` int(10) NOT NULL,
  `Household_size` int(2) NOT NULL,
  `MPCE` int(8) NOT NULL,
  `MPCE_code` varchar(2) NOT NULL,
  `CMPCE_code` varchar(2) NOT NULL,
  `Household_type` int(1) NOT NULL COMMENT 'For rural areas: self-employed in non-agriculture-1, agricultural labour-2, other labour-3, self-employed in agriculture-4, others-9. For urban areas: self-employed-1, regular wage/salary earning-2, casual labour-3, others-9',
  `Religion_Code` int(1) NOT NULL COMMENT 'Hinduism-1, Islam-2, Christianity-3, Sikhism-4, Jainism-5, Buddhism-6, Zoroastrianism-7, Others-9',
  `Social_group` int(1) NOT NULL COMMENT 'Scheduled Tribe-1, Scheduled Caste-2, Other Backward Class-3, Others-9',
  `Land_possessed` int(8) NOT NULL,
  `Dwelling_code` int(1) NOT NULL COMMENT 'owned-1, hired-2, no dwelling unit-3, others-9',
  `Type_dwelling` int(1) NOT NULL COMMENT 'independent house-1, flat-2, others-9',
  `Type_of_structure` int(1) NOT NULL COMMENT 'katcha-1, semi-pucca-2, pucca-3',
  `Covered_area` int(6) NOT NULL,
  `Cooking_code` varchar(2) NOT NULL COMMENT 'coke, coal-01, firewood and chips-02, LPG-03, gobar gas-04, dung cake-05, charcoal-06, kerosene-07, electricity-08, others-99, no cooking arrangement-10',
  `Lighting_code` int(1) NOT NULL COMMENT 'kerosene-1, other oil-2, gas-3, candle-4, electricity-5, others-9, no lighting arrangement-6',
  `Meals_taken_outside` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Ceremony_performed` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `PDS_purchase` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Do_all_members_of_household_get_enough_food_everyday` int(1) NOT NULL COMMENT 'yes: throughout the year-1, some months of the year-2; no-3',
  `Not_get_food_in_the_month_of_January` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_February` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_March` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_April` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_May` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_June` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_July` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_August` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_September` varchar(2) NOT NULL,
  `Not_get_food_in_the_month_of_October` varchar(2) NOT NULL,
  `Not_get_food in_the_month_of_November` varchar(2) NOT NULL,
  `Not_get_food in_the_month_of_December` varchar(2) NOT NULL,
  `Total_number_of_months_not_getting_food` varchar(2) NOT NULL,
  `Whether_Asked` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Time_Canvass` int(3) NOT NULL,
  `Person_Serial_Number` varchar(3) NOT NULL,
  `Relation_to_head` int(1) NOT NULL COMMENT 'self-1, spouse of head-2, married child-3, spouse of married child-4, unmarried child-5, grandchild-6, father/mother/father-in-law/mother-in-law-7, brother/sister/brother-in-law/sister-in-law/other relatives-8, servants/employees/other non-relatives-9',
  `Sex` int(1) NOT NULL COMMENT 'Male-1, Female-2',
  `Age` int(2) NOT NULL COMMENT 'In Years',
  `Marital_Status` int(1) NOT NULL COMMENT 'never married-1, currently married-2, widowed-3, divorced/separated-4',
  `General_Education_Code` varchar(2) NOT NULL COMMENT 'not literate-01, literate without formal schooling-02, literate but below primary-03, primary-04, middle-05, secondary-06, higher secondary-07, diploma/certificate course-08, graduate-10, Post-graduate and above-11',
  `Usual_Principal_Activity_Status_Code` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Usual_Principal_Activity_NIC_Code` varchar(2) NOT NULL COMMENT 'As per NIC 1998 Codes',
  `Subsidiary_Activity_Status_Code` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Subsidiary_Activity_NIC_Code` varchar(2) NOT NULL COMMENT 'As per NIC 1998 Codes',
  `Current_Weekly_Activity_Status_Code` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Current_Weekly_Activity_NIC_Code` varchar(2) NOT NULL COMMENT 'As per NIC 1998 Codes',
  `Days_stayed_away` int(2) NOT NULL,
  `Number_of_meals_per_day` int(1) NOT NULL,
  `Meals_at_school` int(2) NOT NULL,
  `Meals_from_employer` int(2) NOT NULL,
  `Meals_from_other_sources` int(2) NOT NULL,
  `Meals_on_payment` int(2) NOT NULL,
  `Meal_at_home` int(2) NOT NULL,
  `State_Group_Code` varchar(2) NOT NULL,
  `Revised_Status_Code(US_plus_PS)` varchar(2) NOT NULL,
  `Revised_NIC_Code` varchar(2) NOT NULL,
  `Worker_CD` int(1) NOT NULL,
  `Lot` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
