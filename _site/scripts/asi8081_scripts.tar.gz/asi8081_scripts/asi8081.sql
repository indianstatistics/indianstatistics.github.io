-- Copyright 2012 Centre for Economic Studies and Planning (CESP)
-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
--
-- Database: `ASI_80_81`
--
DROP DATABASE IF EXISTS ASI_80_81;
CREATE DATABASE ASI_80_81;
USE ASI_80_81;
-- --------------------------------------------------------
--
-- Table structure for table `A`
--
CREATE TABLE IF NOT EXISTS `A` (
  `Part_Code` varchar(1) NOT NULL,
  `FILLER_c` varchar(1) NOT NULL,
  `State_Code` varchar(2) NOT NULL,
  `Running_Serial_No` varchar(5) NOT NULL,
  `NIC_70_1_Original_NIC70` int(4) NOT NULL,
  `Filler_a` varchar(4) NOT NULL,
  `Filler_b` varchar(4) NOT NULL,
  `Filler_d` varchar(4) NOT NULL,
  `Filler_e` varchar(4) NOT NULL,
  `Filler_f` varchar(4) NOT NULL,
  `Filler_g` varchar(1) NOT NULL,
  `MULTIPLIER` int(3) NOT NULL,
  `Year_of_Survey` int(4) NOT NULL,
  `Filler_h` varchar(4) NOT NULL,
  `Dummy_State_Code` varchar(2) NOT NULL,
  `Region_Code` varchar(4) NOT NULL,
  `Ownership_Code` varchar(1) NOT NULL,
  `Organisation_Code` varchar(1) NOT NULL,
  `Management_Code` varchar(1) NOT NULL,
  `Scheme_Code` varchar(1) NOT NULL,
  `District_Code` varchar(2) NOT NULL,
  `Block_Code` varchar(2) NOT NULL,
  `Serial_No_as_given_in_Schedules` int(5) NOT NULL,
  `Permanent_Serial_No` int(5) NOT NULL,
  `Location_Code` int(1) NOT NULL,
  `Area_Code` int(1) NOT NULL,
  `Year_of_Initial_Production` int(41) NOT NULL,
  `Year_of_Initial_Production_Code` int(1) NOT NULL,
  `Open_Close_Code` int(1) NOT NULL,
  `Power_Code` int(1) NOT NULL,
  `Filler_i` varchar(4) NOT NULL,
  `Filler_j` varchar(2) NOT NULL,
  `Filler_k` varchar(2) NOT NULL,
  `Ancillary_Unit` int(1) NOT NULL,
  `Registered` int(1) NOT NULL,
  `Filler_l` varchar(2) NOT NULL,
  `No_of_Factories` int(14) NOT NULL,
  `Addition_to_Land_Building` int(14) NOT NULL,
  `Supplement_to_Emoluments` int(14) NOT NULL,
  `Fixed_Capital_Opening` int(14) NOT NULL,
  `Fixed_Capital_Closing` int(14) NOT NULL,
  `Rent_for_use_of_Land` int(14) NOT NULL,
  `Total_Rent` int(14) NOT NULL,
  `Gross_Value_of_Plant_&_Machinery` int(14) NOT NULL,
  `Physical_Working_Capital_Opening` int(14) NOT NULL,
  `Physical_Working_Capital_Closing` int(14) NOT NULL,
  `Working_Capital_Opening` int(14) NOT NULL,
  `Working_Capital_Closing` int(14) NOT NULL,
  `Outstanding_Loans_Opening` int(14) NOT NULL,
  `Outstanding_Loans_Closing` int(14) NOT NULL,
  `Mandays_Employees` int(14) NOT NULL,
  `Workers_Nos` int(14) NOT NULL,
  `Total_Persons_Engaged` int(14) NOT NULL,
  `Wages_to_Workers` int(14) NOT NULL,
  `Salaries_to_Employees` int(14) NOT NULL,
  `Bonus_to_Employees` int(14) NOT NULL,
  `Imputed_value_of_benefits_in_kinds` int(14) NOT NULL,
  `Total_value_of_Benefits` int(14) NOT NULL,
  `Fuels_Consumed` int(14) NOT NULL,
  `Material_Consumed` int(14) NOT NULL,
  `Industrial_Services_Purchased` int(14) NOT NULL,
  `Non_industrial_Services_Purchased` int(14) NOT NULL,
  `Total_Input` int(14) NOT NULL,
  `Interest` int(14) NOT NULL,
  `Receipts_from_Services_rendered_to_others` int(14) NOT NULL,
  `Product` int(14) NOT NULL,
  `Other_Output` int(14) NOT NULL,
  `Total_Output` int(14) NOT NULL,
  `Depreciation` int(14) NOT NULL,
  `Value_Added` int(14) NOT NULL,
  `Stock_Of_Material_fuels_Stores_etc_Opening` int(14) NOT NULL,
  `Stock_Of_Materials_fuels_Stores_etc_Closing` int(14) NOT NULL,
  `Stock_Of_Semi_Finished_Goods_Opening` int(14) NOT NULL,
  `Stock_Of_Semi_Finished_Goods_Closing` int(14) NOT NULL,
  `Products_&_Bye_Products_Opening` int(14) NOT NULL,
  `Products_&_Bye_Products_Closing` int(14) NOT NULL,
  `No_of_Working_Days` int(14) NOT NULL,
  `All_Workers_Mandays` int(14) NOT NULL,
  `Bonus_Paid_to_Workers` int(14) NOT NULL,
  `All_Employees_Nos` int(14) NOT NULL,
  `Bonus_paid_to_Employees` int(14) NOT NULL,
  `Employees_Contribution_to_Old_age_benefits` int(14) NOT NULL,
  `Employees Contribution to other benefits` int(14) NOT NULL COMMENT ' ( other social security changes)',
  `FILLER` varchar(14) NOT NULL,
  `Direct_exp_maternity_benefits_etc` int(14) NOT NULL,
  `Other_Group_benefits` int(14) NOT NULL,
  `Rent_other_than_use_of_Land` int(14) NOT NULL,
  `Invested_Capital` int(14) NOT NULL,
  `Wages_to_worker` int(14) NOT NULL COMMENT '(including Bonus to Workers)',
  `Total_Emoluments` int(14) NOT NULL,
  `Other_Input` int(14) NOT NULL,
  `Net-Income` int(14) NOT NULL,
  `Value_of_addition_to_Fixed_capital` int(14) NOT NULL,
  `Change_in_Stock_of_Physical_Working_Capital` int(14) NOT NULL,
  `Profits` int(14) NOT NULL,
  `Gross_Fixed_Capital_Formation` int(14) NOT NULL,
  `Addition_in_Stock_of_Materials` int(14) NOT NULL,
  `Addition_in_Stock_of_Materials2` int(14) NOT NULL COMMENT '(Semi-Finished Goods)',
  `Addition_in_Stock_of_Finished_Goods` int(14) NOT NULL,
  `Gross_Capital_Formation` int(14) NOT NULL,
  `Other_employees_benefits` int(14) NOT NULL,
  `Productive_Capital` int(14) NOT NULL,
  `Filler1` varchar(14) NOT NULL,
  `Filler2` varchar(14) NOT NULL,
  `Filler3` varchar(14) NOT NULL,
  `Filler4` varchar(14) NOT NULL,
  `Filler5` varchar(14) NOT NULL,
  `Filler6` varchar(14) NOT NULL,
  `Filler7` varchar(14) NOT NULL,
  `Filler8` varchar(14) NOT NULL,
  `Filler9` varchar(2) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
