-- Copyright 2014 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `ASI_09_10`
--
DROP DATABASE IF EXISTS ASI_09_10;
CREATE DATABASE ASI_09_10;
USE ASI_09_10;

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_A`
--

CREATE TABLE IF NOT EXISTS `BLOCK_A` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always A',
  `DSL` int(6) NOT NULL,
  `PSL_number` varchar(5) NOT NULL,
  `Scheme_code` int(1) NOT NULL COMMENT 'Census-1;Sample-2',
  `Industrial_code_as_per_frame` varchar(4) NOT NULL COMMENT '4-digit level of NIC-08',
  `Industrial_code_as_per_return` varchar(5) NOT NULL COMMENT '5-digit level of NIC-08',
  `State_code` varchar(2) NOT NULL COMMENT 'Refer to the State Code List',
  `District_code` varchar(2) NOT NULL,
  `Rural/urban_code` int(1) NOT NULL COMMENT 'Rural-1;Urban-2',
  `RO/SRO_code` varchar(5) NOT NULL,
  `Number_of_units` int(3) NOT NULL,
  `Status_of_unit` int(2) NOT NULL COMMENT 'Refer to supplementary document for details on the different codes',
  `Bonus` int(14) NOT NULL,
  `Provident_fund` int(14) NOT NULL,
  `Welfare` int(14) NOT NULL,
  `Number_of_working_days_manufacturing` int(3) NOT NULL,
  `Number_of_working_days_non_manufacturing` int(3) NOT NULL,
  `Number_of_working_days_total` int(3) NOT NULL,
  `Cost_of_production` int(12) NOT NULL,
  `Percentage_share_of_products_and_by_products_directly_exported` int(3) NOT NULL,
  `Inflation/multiplier_factor` decimal(4,4) NOT NULL COMMENT 'In 9999.9999 format',
  `Filler` varchar(63) NOT NULL COMMENT 'Padded with 0 or blank',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Identification Block for Official Use';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_B`
--

CREATE TABLE IF NOT EXISTS `BLOCK_B` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always B',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Type_of_organisation` int(2) NOT NULL COMMENT 'Refer to the supplementary document containing code lists',
  `Type_of_ownership` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing code lists',
  `Total_number_of_units_of_the_company` int(4) NOT NULL,
 `Original_value_of_investment_in_plant_and_machinery_range_codes` int(1) NOT NULL COMMENT 'Less than or equal to one crore-1; more than 1 crore but less than or equal to 5 crore-2; more than 5 crore but less than or equal to 10 crore-3; more than 10 crore-4',
  `Whether_the_unit_has_ISO_certification_14000_series` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Year_of_initial_production` int(4) NOT NULL,
  `Accounting_year_from` varchar(6) NOT NULL,
  `Accounting_year_to` varchar(6) NOT NULL,
  `Number_of_months_of_operation` int(2) NOT NULL,
  `Does_the_unit_have_a_computerised_a/c_system` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Can_the_unit_supply_ASI_data_in_floppy` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Filler` varchar(139) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='To be filled by factory owners';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_C`
--

CREATE TABLE IF NOT EXISTS `BLOCK_C` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always C',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_number` int(2) NOT NULL COMMENT 'To be entered as printed in the schedule',
  `Opening_as_on_1` int(12) NOT NULL,
  `Due_to_revaluation` int(12) NOT NULL,
  `Actual_addition` int(12) NOT NULL,
  `Deduction_and_adjustment_during_the_year` int(12) NOT NULL,
  `Closing_as_on_1` int(12) NOT NULL,
  `Up_to_year_beginning` int(12) NOT NULL,
  `Provided_during_the_year` int(12) NOT NULL,
  `Adjustment_during_the_year` int(12) NOT NULL,
  `Up_to_year_end` int(12) NOT NULL,
  `Opening_as_on_2` int(12) NOT NULL,
  `Closing_as_on_2` int(12) NOT NULL,
  `Filler` varchar(34) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_D`
--

CREATE TABLE IF NOT EXISTS `BLOCK_D` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always D',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_number` int(2) NOT NULL COMMENT 'To be entered as printed in the schedule',
  `Opening` int(12) NOT NULL COMMENT 'In Rupees',
  `Closing` int(12) NOT NULL COMMENT 'In Rupees',
  `Filler` varchar(142) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital and Loans';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_E`
--

CREATE TABLE IF NOT EXISTS `BLOCK_E` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always E',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_number` int(2) NOT NULL COMMENT 'As printed in the schedule',
  `Mandays_worked_manufacturing` int(8) NOT NULL,
  `Mandays_worked_nonmanufacturing` int(8) NOT NULL,
  `Mandays_worked_total` int(10) NOT NULL,
  `Average_number_of_persons_worked` int(8) NOT NULL,
  `Number_of_mandays_paid_for` int(10) NOT NULL,
  `Wages/salaries` int(12) NOT NULL COMMENT 'In Rupees',
  `Filler` varchar(110) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment and Labour Cost';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_F`
--

CREATE TABLE IF NOT EXISTS `BLOCK_F` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always F',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Work_done_by_others` int(12) NOT NULL COMMENT 'Item1',
  `Repair_and_maintenance_of_building_and_other_construction` int(12) NOT NULL COMMENT 'Item2i',
  `Repair_&_maintenance_of_other_fixed_assets` int(12) NOT NULL COMMENT 'Item2ii',
  `Operating_expenses` int(12) NOT NULL COMMENT 'Item3',
  `Non_operating_expenses` int(12) NOT NULL COMMENT 'Item4',
  `Insurance_charges` int(12) NOT NULL COMMENT 'Item5',
  `Rent_paid_for_plant_and_machinery_and_other_fixed_assets` int(12) NOT NULL COMMENT 'Item6',
  `Total_expenses` int(12) NOT NULL COMMENT 'Item7=Sum of items 1 to 6',
  `Rent_paid_for_buildings` int(12) NOT NULL COMMENT 'Item8',
  `Rent_paid_for_land_on_lease_or_royalties_on_mines_quarries_etc.` int(12) NOT NULL COMMENT 'Item9',
  `Interest_paid` int(12) NOT NULL COMMENT 'Item10',
  `Purchase_value_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL COMMENT 'Item11',
  `Filler` varchar(24) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Expenses';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_G`
--

CREATE TABLE IF NOT EXISTS `BLOCK_G` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_Code` varchar(2) NOT NULL COMMENT 'Always G',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Income_from_services` int(12) NOT NULL COMMENT 'Item1',
  `Variation_in_stock_of_semi_finished_goods` int(12) NOT NULL COMMENT 'Item2',
  `Value_in_electricity_generated_and_sold` int(12) NOT NULL COMMENT 'Item3',
  `Value_of_own_construction` int(12) NOT NULL COMMENT 'Item4',
  `Net_balance_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL COMMENT 'Item5',
  `Rent_received_for_plant_and_machinery_and_other_fixed_assets` int(12) NOT NULL COMMENT 'Item6',
  `Total_receipts` int(12) NOT NULL COMMENT 'Item7=Sum of Items 1 to 6',
  `Rent received_for_building` int(12) NOT NULL COMMENT 'Item8',
  `Rent_received_for_land_on_lease_or_royalties_on_mines_etc.` int(12) NOT NULL COMMENT 'Item9',
  `Interest_received` int(12) NOT NULL COMMENT 'Item10',
  `Sale_value_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL COMMENT 'Item11',
  `Total_subsidies` int(12) NOT NULL COMMENT 'Item12',
  `Filler` varchar(24) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Output/Receipts';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_H`
--

CREATE TABLE IF NOT EXISTS `BLOCK_H` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always H',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_number` int(2) NOT NULL  COMMENT 'As printed in the schedule',
  `Item_code` int(5) NOT NULL COMMENT 'Refer to ASICC Code List',
  `Unit_of_quantity_code` int(3) NOT NULL,
  `Quantity_consumed` decimal(11,3) NOT NULL COMMENT 'As 999999999999.999',
  `Purchase_value` int(12) NOT NULL COMMENT 'In Rupees',
  `Rate_per_unit` decimal(12,2) NOT NULL COMMENT 'in Rs.0.00; As 999999999999.99',
  `Filler` varchar(116) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Input Items-Indigenous Items Consumed';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_I`
--

CREATE TABLE IF NOT EXISTS `BLOCK_I` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always I',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_number` int(2) NOT NULL COMMENT 'As printed in the schedule',
  `Item_code` int(5) NOT NULL COMMENT 'Refer to ASICC Code List',
  `Unit_of_quantity_code` int(3) NOT NULL,
  `Quantity_consumed` decimal(11,3) NOT NULL COMMENT 'As Rs. 999999999999.999',
  `Purchase_value_at_delivery` int(12) NOT NULL COMMENT 'In Rupees',
  `Rate_per_unit` decimal(12,2) NOT NULL COMMENT 'As Rs. 999999999999.99',
  `Filler` varchar(116) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Input Items-Directly Imported Items Only (Consumed)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_J`
--

CREATE TABLE IF NOT EXISTS `BLOCK_J` (
  `Year` varchar(2) NOT NULL COMMENT '10 for ASI 2009-10',
  `Block_code` varchar(2) NOT NULL COMMENT 'Always J',
  `DSL` int(6) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_number` int(2) NOT NULL COMMENT 'As printed in the schedule',
  `Item_code` int(5) NOT NULL COMMENT 'Refer to ASICC Code List',
  `Unit_of_quantity_code` int(3) NOT NULL,
  `Quantity_manufactured` decimal(11,3) NOT NULL COMMENT 'As Rs. 99999999999.999',
  `Quantity_sold` decimal(11,3) NOT NULL COMMENT 'As Rs. 99999999999.999',
  `Gross_sale_value` int(12) NOT NULL COMMENT 'In Rupees',
  `Excise_duty` int(12) NOT NULL,
  `Sales_tax` int(12) NOT NULL,
  `Others` int(12) NOT NULL,
  `Total` int(12) NOT NULL,
  `Per_unit_net_sale_value` decimal(12,2) NOT NULL COMMENT 'In Rs. 999999999999.99',
  `Exfactory_value_of_output` int(12) NOT NULL COMMENT 'In Rupees; Per Unit Net Sale Value multiplied by Quantity Manufactured',
  `Filler` varchar(41) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Products and By-Products (Manufactured by the Unit)';
