# Copyright 2012 Centre for Economic Studies and Planning (CESP)
#
# This script was written by Sakshi Jain (jainsakshi2016 at
# gmail dot com) as part of an initiative directed by Vikas Rawal
# (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
# and ASI data. This initiative is supported by the CAS programme of
# CESP.
# 
# To run this, you need to specify below the ip address/hostname of
# the mysql server, the mysql username and mysql password.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.
#! /bin/sh
server=127.0.0.1 # ip address/hostname of the mysql server 
username="USERNAME"   # mysql user name
pass="PASSWORD"    # password of the mysql user
time_start=`date +%s`
echo "Scripts to read ASI 1993-94 data called at `date`"
rm -Rf ../csv999pibs
mkdir ../csv999pibs
./asi9394.awk ../Data/ASI93_94.TXT
echo "Data parsed into csv files for each level at `date`"
mysql --host=$server --user=$username --password=$pass < asi9394.sql
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK1_RC11.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK4_RC040.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK4A_RC040_SRC014.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK5_RC051.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK5_RC052.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK5_RC053.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK5_RC054.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK7_RC071.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK7_RC072.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK7_RC073.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK7_RC074.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK8_RC081.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK8_RC082.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK9_RC091.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK10_RC101.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK10_RC102.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK11_RC111.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK12_RC121.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK13_RC131.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK13A_RC132.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK13A_RC133.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK14_RC141.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_93_94 --local ../csv999pibs/BLOCK14A_RC142.csv
echo "Mysql database created at `date`"
echo "Now cleaning up..."
rm -Rf ../csv999pibs
time_end=`date +%s`
time_exec=`expr $(( $time_end - $time_start ))`
echo "The script took $time_exec seconds to finish."
