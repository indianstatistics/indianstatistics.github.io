-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.


SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `ASI_89_90`
--
DROP DATABASE IF EXISTS ASI_89_90;
CREATE DATABASE ASI_89_90;
USE ASI_89_90;


-- --------------------------------------------------------

--
-- Table structure for table `BLOCK1_RC011`
--

CREATE TABLE IF NOT EXISTS `BLOCK1_RC011` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `RSNO_Reported` int(5) NOT NULL,
  `PSNPO` int(5) NOT NULL,
  `Number_of_Units` int(3) NOT NULL,
  `State/District` varchar(4) NOT NULL,
  `FOD_Region_Code` varchar(3) NOT NULL,
  `R/U/M_Code` int(1) NOT NULL,
  `Backward_Area_Code` int(1) NOT NULL,
  `Open/Closed_Code` int(1) NOT NULL,
  `Year_of_Initial_Production` int(4) NOT NULL,
  `Type_of_Organisation` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Type_of_Ownership` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Type_of_Management` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Whether_ancillary_unit` int(1) NOT NULL COMMENT 'Yes-1;No-2',
  `Whether_registered` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Accounting_Year_Closing` int(6) NOT NULL COMMENT 'DDMMYY',
  `Months_of_Operation` int(2) NOT NULL,
  `Type_of_Power_Used` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Number_of_manufacturing_days` int(3) NOT NULL,
  `Total_Number_of_Working_Days` int(3) NOT NULL,
  `Total_Number_of_shifts` int(4) NOT NULL,
  `Length_of_Shifts` int(2) NOT NULL,
  `Number_of_Records_Block4` int(1) NOT NULL,
  `Number_of_Records_Block5` int(1) NOT NULL,
  `Number_of_Records_Block7` int(1) NOT NULL,
  `Number_of_Records_Block8` int(1) NOT NULL,
  `Number_of_Records_Block9` int(1) NOT NULL,
  `Number_of_Records_Block10` int(1) NOT NULL,
  `Number_of_Records_Block11` int(1) NOT NULL,
  `Number_of_Records_Block12` int(1) NOT NULL,
  `Number_of_Records_Block13` int(1) NOT NULL,
  `Number_of_Records_Block13A` int(1) NOT NULL,
  `Number_of_Records_Block14` int(1) NOT NULL,
  `Number_of_Records_Block_14A` int(1) NOT NULL,
  `Total` int(2) NOT NULL,
  `Filler` varchar(38) NOT NULL,
  `Update_Code_(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='General Information';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4A_RC050`
--

CREATE TABLE IF NOT EXISTS `BLOCK4A_RC050` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `P&M_Undepreciated_Opening` int(11) NOT NULL,
  `P&M_Leased_in_opening` int(11) NOT NULL,
  `P&M_Leased_out_opening` int(11) NOT NULL,
  `P&M_Total_opening` int(11) NOT NULL,
  `P&M_Underpreciated_closing` int(11) NOT NULL,
  `P&M_Leased_in_closing` int(11) NOT NULL,
  `P&M_Leased_out_closing` int(11) NOT NULL,
  `P&M_Total_closing` int(11) NOT NULL,
  `Filler` varchar(17) NOT NULL,
  `Update_Code_(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Plant & Machinery';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC041`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC041` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC042`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC042` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC043`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC043` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC044`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC044` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC045`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC045` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC046`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC046` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` int(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC047`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC047` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC048`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC048` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC049`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC049` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Gross_Opening` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening_Net` int(11) NOT NULL,
  `Closing_Net` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK5_RC051`
--

CREATE TABLE IF NOT EXISTS `BLOCK5_RC051` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Raw_materials_and_components` int(11) NOT NULL,
  `Fuels_and_lubricants` int(11) NOT NULL,
  `Spares,stores_and_others` int(11) NOT NULL,
  `Semifinished_goods` int(11) NOT NULL,
  `Finished_goods` int(11) NOT NULL,
  `Total_inventory` int(11) NOT NULL,
  `Outstanding_Loans` int(11) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital & Loans, Opening Balance (Column 3)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK5_RC052`
--

CREATE TABLE IF NOT EXISTS `BLOCK5_RC052` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Total_inventory` int(11) NOT NULL,
  `Cash_in_hand_and_bank` int(11) NOT NULL,
  `Sundry_debtors` int(11) NOT NULL,
  `Other_current_assets` int(11) NOT NULL,
  `Sundry_creditors` int(11) NOT NULL,
  `Overdrafts_etc` int(11) NOT NULL,
  `Other_current_liabilities` int(11) NOT NULL,
  `Working_capital` int(11) NOT NULL,
  `Filler` int(17) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital (contd), Opening Balance';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK5_RC053`
--

CREATE TABLE IF NOT EXISTS `BLOCK5_RC053` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Raw_materials_and_components` int(11) NOT NULL,
  `Fuels_and_lubricants` int(11) NOT NULL,
  `Spares,stores_and_others` int(11) NOT NULL,
  `Semifinished_goods` int(11) NOT NULL,
  `Finished_goods` int(11) NOT NULL,
  `Total_inventory` int(11) NOT NULL,
  `Outstanding_loans` int(11) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital & Loans, Closing Balance (Column 4)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK5_RC054`
--

CREATE TABLE IF NOT EXISTS `BLOCK5_RC054` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Total_inventory` int(11) NOT NULL,
  `Cash_in_hand_and_bank` int(11) NOT NULL,
  `Sundry_debtors` int(11) NOT NULL,
  `Other_current_assets` int(11) NOT NULL,
  `Sundry_creditors` int(11) NOT NULL,
  `Overdrafts_etc` int(11) NOT NULL,
  `Other_current_liabilities` int(11) NOT NULL,
  `Working_capital` int(11) NOT NULL,
  `Filler` varchar(17) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital (contd), Closing Balance';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC071`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC071` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Employment_through_contractors` int(11) NOT NULL,
  `Supervisory_&_managerial_staff` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment, Manufacturing Days (column 3)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC072`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC072` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Employment_through_contractors` int(11) NOT NULL,
  `Supervisory_&_managerial_staff` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment, Non-Manufacturing Days (column 4)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC073`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC073` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Employment_through_contractors` int(11) NOT NULL,
  `Supervisory_and_managerial_staff` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment, Total Days (column 5)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC074`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC074` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Men` int(7) NOT NULL,
  `Women` int(7) NOT NULL,
  `Children` int(7) NOT NULL,
  `Employed_through_contractors` int(7) NOT NULL,
  `Supervisory_and_managerial_staff` int(7) NOT NULL,
  `Other_employees` int(7) NOT NULL,
  `Working_proprietors` int(7) NOT NULL,
  `Unpaid_family_workers` int(7) NOT NULL,
  `If_cooperative_etc` int(7) NOT NULL,
  `Total` int(7) NOT NULL,
  `Filler` varchar(35) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment(contd.)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK8_RC081`
--

CREATE TABLE IF NOT EXISTS `BLOCK8_RC081` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Wages_and_salaries_workers` int(10) NOT NULL,
  `Bonus_Workers` int(10) NOT NULL,
  `Contribution_to_PF_workers` int(10) NOT NULL,
  `Welfare_expense_workers` int(10) NOT NULL,
  `Total_labour_cost_workers` int(10) NOT NULL,
  `Wages_and_salaries_supervisory_staff` int(10) NOT NULL,
  `Bonus_supervisory_staff` int(10) NOT NULL,
  `Contribution_to_PF_supervisory_staff` int(10) NOT NULL,
  `Welfare_expenses_supervisory_staff` int(10) NOT NULL,
  `Total_labour_cost_supervisory_staff` int(10) NOT NULL,
  `Filler` varchar(5) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Labour Cost';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK8_RC082`
--

CREATE TABLE IF NOT EXISTS `BLOCK8_RC082` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Wages_and_salaries_others` int(10) NOT NULL,
  `Bonus_Others` int(10) NOT NULL,
  `Contribution_to_PF_others` int(10) NOT NULL,
  `Welfare_expense_others` int(10) NOT NULL,
  `Total_labour_cost_others` int(10) NOT NULL,
  `Wages_and_salaries_total` int(10) NOT NULL,
  `Bonus_total` int(10) NOT NULL,
  `Contribution_to_PF_total` int(10) NOT NULL,
  `Welfare_expenses_total` int(10) NOT NULL,
  `Total_labour_cost_total` int(10) NOT NULL,
  `Filler` varchar(5) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Labour Cost (contd.)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK9_RC091`
--

CREATE TABLE IF NOT EXISTS `BLOCK9_RC091` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Item_Code_2` varchar(4) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_Code_3` varchar(4) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Item_code_4` varchar(4) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `Filler` varchar(1) NOT NULL,
  `Update_Code_(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fuels, electricity etc. consumed';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK10_RC101`
--

CREATE TABLE IF NOT EXISTS `BLOCK10_RC101` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Work_done_by_others` int(10) NOT NULL,
  `Repair_and_maintenance_Total` int(10) NOT NULL,
  `Inward_Freight_etc` int(10) NOT NULL,
  `Rates_and_Taxes` int(10) NOT NULL,
  `Postage,Telephone_etc` int(10) NOT NULL,
  `Insurance_charges` int(10) NOT NULL,
  `Banking_charges` int(10) NOT NULL,
  `Printing_and_stationery` int(10) NOT NULL,
  `Miscellaneous` int(10) NOT NULL,
  `Total` int(10) NOT NULL,
  `Filler` varchar(5) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Expenditure';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK10_RC102`
--

CREATE TABLE IF NOT EXISTS `BLOCK10_RC102` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Rent_of_land_etc` int(10) NOT NULL,
  `Rent_for_Building` int(10) NOT NULL,
  `Rent_for_P&M` int(10) NOT NULL,
  `Rent_for_other_assets` int(10) NOT NULL,
  `Total_rent` int(10) NOT NULL,
  `Interest` int(10) NOT NULL,
  `Labour_Cost_Own_Construction` int(10) NOT NULL,
  `Others_Own_Construction` int(10) NOT NULL,
  `Total_Own_Construction` int(10) NOT NULL,
  `Filler` varchar(15) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Expenditure (contd)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK11_RC111`
--

CREATE TABLE IF NOT EXISTS `BLOCK11_RC111` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Work_done_for_others` int(10) NOT NULL,
  `Receipt_for_non-industrial_services` int(10) NOT NULL,
  `Variation_in_stock of_semifinished_goods` int(10) NOT NULL,
  `Value_of_electricity_sold` int(10) NOT NULL,
  `Value_of_own_construction` int(10) NOT NULL,
  `Total` int(10) NOT NULL,
  `Sale_value_of_goods_sold_etc` int(10) NOT NULL,
  `Purchase_value_of_goods_sold_etc` int(10) NOT NULL,
  `Filler` varchar(25) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Output/Receipts';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK12_RC121`
--

CREATE TABLE IF NOT EXISTS `BLOCK12_RC121` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Electricity_generated` int(11) NOT NULL,
  `Electricity_purchased` int(11) NOT NULL,
  `Electricity_consumed` int(11) NOT NULL,
  `Electricity_sold` int(11) NOT NULL,
  `Filler` varchar(61) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Electricity';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK13A_RC132`
--

CREATE TABLE IF NOT EXISTS `BLOCK13A_RC132` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1a` int(11) NOT NULL,
  `Value_1a` int(11) NOT NULL,
  `Qty_1b` int(11) NOT NULL,
  `Value_1b` int(11) NOT NULL,
  `Item_Code_2` varchar(4) NOT NULL,
  `Qty_2a` int(11) NOT NULL,
  `Value_2a` int(11) NOT NULL,
  `Qty_2b` int(11) NOT NULL,
  `Value_2b` int(11) NOT NULL,
  `Filler` varchar(9) NOT NULL,
  `Update_Code (1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Industrial Components etc.';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK13_RC131`
--

CREATE TABLE IF NOT EXISTS `BLOCK13_RC131` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Item_code_2` varchar(4) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` varchar(4) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Item_code_4` varchar(4) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `Filler` varchar(1) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Materials etc. consumed';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK13_RC133`
--

CREATE TABLE IF NOT EXISTS `BLOCK13_RC133` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Item_Code_2` varchar(4) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` varchar(4) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Item_code_4` varchar(4) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `Filler` varchar(1) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Imported Materials';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK14A_RC142`
--

CREATE TABLE IF NOT EXISTS `BLOCK14A_RC142` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sales_tax` int(11) NOT NULL,
  `Transport_charges` int(11) NOT NULL,
  `Commission_to_agents` int(11) NOT NULL,
  `Rebates` int(11) NOT NULL,
  `Others` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Distributive expenses etc.';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK14_RC141`
--

CREATE TABLE IF NOT EXISTS `BLOCK14_RC141` (
  `Batch` int(3) NOT NULL,
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Industry_Code` int(4) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to List of State Codes',
  `RSNLO_Coded` int(5) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` varchar(3) NOT NULL,
  `Item code` varchar(4) NOT NULL,
  `Quantity_manufactured` int(11) NOT NULL,
  `Quantity_sold` int(11) NOT NULL,
  `Gross_sale_value` int(11) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sale_tax` int(11) NOT NULL,
  `Filler` varchar(46) NOT NULL,
  `Update_Code(1/2/3)` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Products and by-products etc.';
