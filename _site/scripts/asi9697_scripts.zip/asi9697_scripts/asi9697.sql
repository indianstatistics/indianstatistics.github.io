-- Copyright 2012 Centre for Economic Studies and Planning (CESP)
-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
--
-- Database: `ASI_96_97`
--
DROP DATABASE IF EXISTS ASI_96_97;
CREATE DATABASE ASI_96_97;
USE ASI_96_97;
-- --------------------------------------------------------
--
-- Table structure for table `RC011`
--
CREATE TABLE IF NOT EXISTS `RC011` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` int(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Cont_R_S_L` varchar(5) NOT NULL,
  `Permanent_Sl_No` varchar(5) NOT NULL,
  `No_of_Units` int(3) NOT NULL,
  `State_Dist_Block` varchar(6) NOT NULL,
  `FOD_Region_Code` varchar(5) NOT NULL,
  `R_U_M_Code` int(1) NOT NULL,
  `Backward_Area_Code` int(1) NOT NULL,
  `Year_of_Initial_Prod` int(4) NOT NULL,
  `Type_of_Organisation` int(1) NOT NULL,
  `Type_of_Ownership` int(1) NOT NULL,
  `Type_of_Management` int(1) NOT NULL,
  `Whether_ancillary_unit` int(1) NOT NULL,
  `Wheather_registered` int(1) NOT NULL,
  `Accounting_Year_Closing` varchar(6) NOT NULL,
  `Months_of_operation` varchar(2) NOT NULL,
  `Type_of_power_used` varchar(1) NOT NULL,
  `Open_Closed_Code` varchar(1) NOT NULL,
  `No_of_Records_BLK4` int(2) NOT NULL,
  `Backward_Area_Code_BLK5` varchar(1) NOT NULL,
  `No_of_Records_BLK7` int(1) NOT NULL,
  `No_of_Records_BLK8` int(1) NOT NULL,
  `No_of_Records_BLK9` int(1) NOT NULL,
  `No_of_Records_BLK10` int(1) NOT NULL,
  `No_of_Records_BLK11` int(1) NOT NULL,
  `No_of_Records_BLK12` int(1) NOT NULL,
  `No_of_Records_BLK13` int(2) NOT NULL,
  `No_of_Records_BLK13A` int(2) NOT NULL,
  `No_of_Records_BLK13B` int(2) NOT NULL,
  `No_of_Records _BLK14` int(2) NOT NULL,
  `No_of_Records_BLK14A` int(1) NOT NULL,
  `No_of_Records_Total` int(3) NOT NULL,
  `Frame_Ind_Code` varchar(4) NOT NULL,
  `Filler` varchar(42) NOT NULL,
  `ASI_Year_Last_2_digit` int(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC040`
--

CREATE TABLE IF NOT EXISTS `RC040` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Sub_Record_Code` varchar(3) NOT NULL,
  `Opening_gross` int(12) NOT NULL,
  `Addition_by_revaluation` int(12) NOT NULL,
  `Addition_new` int(12) NOT NULL,
  `Deduction` int(12) NOT NULL,
  `Depreciation_Beginning` int(12) NOT NULL,
  `Depreciation_During` int(12) NOT NULL,
  `Sold_or_Discarded` int(12) NOT NULL,
  `Opening_Net` int(12) NOT NULL,
  `Closing_Net` int(12) NOT NULL,
  `Filler` varchar(4) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC040_SRC014`
--

CREATE TABLE IF NOT EXISTS `RC040_SRC014` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Sub_Record_Code` varchar(3) NOT NULL,
  `P&M_Under_Opening` int(12) NOT NULL,
  `P&M_leased_in_opening_4A_block__2_item_3_column` int(12) NOT NULL,
  `P&M_leased_in_opening_4A_block__3_item_3_column` int(12) NOT NULL,
  `P&M_Total_opening` int(12) NOT NULL,
  `ASI_Year_Last_2_digit_4A_block_1_item_4_column` varchar(12) NOT NULL,
  `P&M_Leased_in_closing` int(12) NOT NULL,
  `P&M_Leased_out_closing` int(12) NOT NULL,
  `P&M_Total_closing` int(12) NOT NULL,
  `Filler` varchar(16) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC051`
--

CREATE TABLE IF NOT EXISTS `RC051` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` int(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Raw_materials_&_components` int(12) NOT NULL,
  `Fuels_and_lubricants` int(12) NOT NULL,
  `Spares_stpres_and_others` int(12) NOT NULL,
  `Semi_finished_goods` int(12) NOT NULL,
  `Finished_goods` int(12) NOT NULL,
  `Total_inventory` int(12) NOT NULL,
  `Filler` varchar(40) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC052`
--

CREATE TABLE IF NOT EXISTS `RC052` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Cash_in_hand_and_bank` int(12) NOT NULL,
  `Sundry_debtors` int(12) NOT NULL,
  `Other_current_assets` int(12) NOT NULL,
  `Sundry_creditors` int(12) NOT NULL,
  `Overdrafts_etc` int(12) NOT NULL,
  `Other_current_liabilities` int(12) NOT NULL,
  `Working_capital` int(12) NOT NULL,
  `Outstanding_loan` int(12) NOT NULL,
  `Filler` varchar(16) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC053`
--

CREATE TABLE IF NOT EXISTS `RC053` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Raw_materials_&_components` int(12) NOT NULL,
  `Fuels_and_lubricants` int(12) NOT NULL,
  `Spares_stpres_and_others` int(12) NOT NULL,
  `Semi_finished_goods` int(12) NOT NULL,
  `Finished_goods` int(12) NOT NULL,
  `Total_inventory` int(12) NOT NULL,
  `Filler` varchar(40) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC054`
--

CREATE TABLE IF NOT EXISTS `RC054` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Cash_in_hand_and_bank` int(12) NOT NULL,
  `Sundry_debtors` int(12) NOT NULL,
  `Other_current_assets` int(12) NOT NULL,
  `Sundry_creditors` int(12) NOT NULL,
  `Overdrafts_etc` int(12) NOT NULL,
  `Other_current_liabilities` int(12) NOT NULL,
  `Working_capital` int(12) NOT NULL,
  `Outstanding_loan` int(12) NOT NULL,
  `Filler` varchar(16) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC071`
--

CREATE TABLE IF NOT EXISTS `RC071` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Men` int(12) NOT NULL,
  `Women` int(12) NOT NULL,
  `Children` int(12) NOT NULL,
  `Employment_Through_contractors` int(12) NOT NULL,
  `Sup_&_managerial_staff` int(12) NOT NULL,
  `Other_employees` int(12) NOT NULL,
  `Total` int(12) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC072`
--

CREATE TABLE IF NOT EXISTS `RC072` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Men` int(12) NOT NULL,
  `Women` int(12) NOT NULL,
  `Children` int(12) NOT NULL,
  `Empl_Through_contractors` int(12) NOT NULL,
  `Sup_&_managerial_staff` int(12) NOT NULL,
  `Other_employees` int(12) NOT NULL,
  `Total` int(12) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC073`
--

CREATE TABLE IF NOT EXISTS `RC073` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Men` int(12) NOT NULL,
  `Women` int(12) NOT NULL,
  `Children` int(12) NOT NULL,
  `Empl_Through_contractors` int(12) NOT NULL,
  `Sup_&_managerial_staff` int(12) NOT NULL,
  `Other_employees` int(12) NOT NULL,
  `Total` int(12) NOT NULL,
  `Filler` varchar(28) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC074`
--

CREATE TABLE IF NOT EXISTS `RC074` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Men` int(7) NOT NULL,
  `Women` int(7) NOT NULL,
  `Children` int(7) NOT NULL,
  `Empl_Through_contractors` int(7) NOT NULL,
  `Sup_&_managerial_staff` int(7) NOT NULL,
  `Other_employees` int(7) NOT NULL,
  `Working_proprietors` int(7) NOT NULL,
  `Unpaid_family_workers` int(7) NOT NULL,
  `If_cooperative_etc` int(7) NOT NULL,
  `Total` int(7) NOT NULL,
  `No_of_manufacturing_days` int(7) NOT NULL,
  `Total_no_of_working_days` int(7) NOT NULL,
  `Total_no_of_shifts` int(7) NOT NULL,
  `Length_of_shifts` int(7) NOT NULL,
  `Filler` varchar(14) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC081`
--

CREATE TABLE IF NOT EXISTS `RC081` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Wages_and_salaries_workers` int(11) NOT NULL,
  `Wages_and_salaries_Super_&_Mang_Staff` int(11) NOT NULL,
  `Wages_and_salaries_Others` int(11) NOT NULL,
  `Wages_and_salaries_Total` int(11) NOT NULL,
  `Bonus_workers` int(11) NOT NULL,
  `Bonus_Super_&_Mang_Stafff` int(11) NOT NULL,
  `Bonus_Others` int(11) NOT NULL,
  `Bonus_Total` int(11) NOT NULL,
  `Filler` varchar(24) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC082`
--

CREATE TABLE IF NOT EXISTS `RC082` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `filler1` varchar(11) NOT NULL,
  `filler2` varchar(11) NOT NULL,
  `Total_Contribution_to_PF_etc` int(11) NOT NULL,
  `Total_welfare_expenses` int(11) NOT NULL,
  `total_labour_cost` int(11) NOT NULL,
  `filler3` varchar(57) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC091`
--

CREATE TABLE IF NOT EXISTS `RC091` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Filler_1` varchar(1) NOT NULL,
  `Item_code_1` varchar(5) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Filler_2` varchar(1) NOT NULL,
  `Item_Code_2` varchar(5) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Filler_3` varchar(1) NOT NULL,
  `Item_Code_3` varchar(5) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Filler_4` varchar(1) NOT NULL,
  `Item_Code_4` varchar(5) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC101`
--

CREATE TABLE IF NOT EXISTS `RC101` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record-Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Work_done_by_others` int(11) NOT NULL,
  `Repair_&_maint_Machinery` int(11) NOT NULL,
  `Repair_&_maint_Building` int(11) NOT NULL,
  `Repair_&_Maint_Others` int(11) NOT NULL,
  `Inward_Freight_etc` int(11) NOT NULL,
  `Rates_and_Taxes` int(11) NOT NULL,
  `Postage_Telephone_etc` int(11) NOT NULL,
  `Insurance_charges` int(11) NOT NULL,
  `banking_charges` int(11) NOT NULL,
  `Printing_&_stationery` int(11) NOT NULL,
  `Filler` varchar(2) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC102`
--

CREATE TABLE IF NOT EXISTS `RC102` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Miscellaneous` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Rent_of_land_etc` int(11) NOT NULL,
  `Rent_for_Building` int(11) NOT NULL,
  `Rent_for_P&M` int(11) NOT NULL,
  `Rent_for_other_assets` int(11) NOT NULL,
  `Total_rent` int(11) NOT NULL,
  `Interest` int(11) NOT NULL,
  `Purchese_value_of_goods_sold` int(11) NOT NULL,
  `Own_construction_labour_cost` int(11) NOT NULL,
  `Filler` varchar(2) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC111`
--

CREATE TABLE IF NOT EXISTS `RC111` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Own_contruction_others` int(11) NOT NULL,
  `Own_contruction_total` int(11) NOT NULL,
  `Work_done_for_others` int(11) NOT NULL,
  `Receipt_for_non_industrial_services` int(11) NOT NULL,
  `Variation_of_stock_of_semi_finished_googes` int(11) NOT NULL,
  `Value_of_electricity_sold` int(11) NOT NULL,
  `Value_of_own_construction` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Sale_value_of_goods_old_etc` int(11) NOT NULL,
  `Filler` varchar(13) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC121`
--

CREATE TABLE IF NOT EXISTS `RC121` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Electricity_purchased` int(12) NOT NULL,
  `electricity_generated` int(12) NOT NULL,
  `Electricity_sold` int(12) NOT NULL,
  `Electricity_consumed` int(12) NOT NULL,
  `Filler` varchar(64) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC131`
--

CREATE TABLE IF NOT EXISTS `RC131` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Filler_1` varchar(1) NOT NULL,
  `Item_code_1` varchar(5) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Filler_2` varchar(1) NOT NULL,
  `Item_Code_2` varchar(5) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Filler_3` varchar(1) NOT NULL,
  `Item_Code_3` varchar(5) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Filler_4` varchar(1) NOT NULL,
  `Item_Code_4` varchar(5) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC132`
--

CREATE TABLE IF NOT EXISTS `RC132` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Filler` varchar(1) NOT NULL,
  `Item_code_1` varchar(5) NOT NULL,
  `Qty_13A_10_3` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Value _13A_10_4` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Qty_13A_10_5` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Value_13A_10_6` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Filler1` varchar(1) NOT NULL,
  `Item_Code_2` varchar(5) NOT NULL,
  `Qty_13A_10_3_` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Value_13A_10_4_` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Qty_13A_10_5_` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Value_13A_10_6_` int(11) NOT NULL COMMENT 'Blk/Item/col',
  `Filler2` varchar(12) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC133`
--

CREATE TABLE IF NOT EXISTS `RC133` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Filler` varchar(1) NOT NULL,
  `Item_code_1` varchar(5) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Filler1` varchar(1) NOT NULL,
  `Item_Code_2` varchar(5) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Filler2` varchar(1) NOT NULL,
  `Item_Code_3` varchar(5) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Filler3` varchar(1) NOT NULL,
  `Item_Code _4` varchar(5) NOT NULL,
  `Qty _4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC141`
--

CREATE TABLE IF NOT EXISTS `RC141` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Filler_` varchar(1) NOT NULL,
  `Item_code` varchar(5) NOT NULL,
  `Quantity_manufactured` int(11) NOT NULL,
  `Quantity_sold` int(11) NOT NULL,
  `Gross_sale_value` int(11) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sale_tax` int(11) NOT NULL,
  `Dist_Expenses_other` int(11) NOT NULL,
  `Dist_Expenses_total` int(11) NOT NULL,
  `Itenwise_N_S_V_unit` int(11) NOT NULL,
  `Itenwise_Ex_fact_Value` int(11) NOT NULL,
  `Filler` varchar(7) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `RC142`
--

CREATE TABLE IF NOT EXISTS `RC142` (
  `Industry` varchar(4) NOT NULL,
  `Running_Sl_No` varchar(5) NOT NULL,
  `State` varchar(2) NOT NULL,
  `Scheme` varchar(1) NOT NULL,
  `Record_Category` varchar(3) NOT NULL,
  `Link_code` varchar(3) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sale_tax` int(11) NOT NULL,
  `Transport_charges` int(11) NOT NULL,
  `Commission` int(11) NOT NULL,
  `Rebates` int(11) NOT NULL,
  `Other` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(35) NOT NULL,
  `ASI_Year_Last_2_digit` varchar(2) NOT NULL,
  `Multiplier` int(3) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
