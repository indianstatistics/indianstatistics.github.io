# Copyright 2012 Centre for Economic Studies and Planning (CESP)
#
# This script was written by Shreshtha Saraswat (shreshtha.saraswat at
# gmail dot com) as part of an initiative directed by Vikas Rawal
# (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
# and ASI data. This initiative is supported by the CAS programme of
# CESP.
# 
# To run this, you need to specify below the ip address/hostname of
# the mysql server, the mysql username and mysql password.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /bin/sh
server=127.0.0.1 # ip address/hostname of the mysql server 
username="USERNAME"   # mysql user name
pass="PASSWORD"    # password of the mysql user
time_start=`date +%s`
echo "Scripts to read ASI 2005-06 data called at `date`"
rm -Rf ../csv41zap
mkdir ../csv41zap
./asi0506.awk ../Data/asi06m.TXT
echo "Data parsed into csv files for each level at `date`"
mysql --host=$server --user=$username --password=$pass < asi0506.sql
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_A.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_B.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_C.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_D.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_E.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_F.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_G.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_H.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_I.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_05_06 --local ../csv41zap/BLOCK_J.csv
echo "Mysql database created at `date`"
echo "Now cleaning up..."
rm -Rf ../csv41zap
time_end=`date +%s`
time_exec=`expr $(( $time_end - $time_start ))`
echo "The script took $time_exec seconds to finish."
