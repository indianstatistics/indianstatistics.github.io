-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `ASI_05_06`
--
DROP DATABASE IF EXISTS ASI_05_06;
CREATE DATABASE ASI_05_06;
USE ASI_05_06;

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_A`
--

CREATE TABLE IF NOT EXISTS `BLOCK_A` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `PSL_Number` varchar(5) NOT NULL,
  `Scheme_Code` int(1) NOT NULL COMMENT 'Census-1;Sample-2',
  `Industrial_Code_as_per_Frame` varchar(4) NOT NULL COMMENT '4-digit level of NIC-04',
  `Industrial_Code_as_per_Return` varchar(5) NOT NULL COMMENT '5-digit level of NIC-04',
  `State_Code` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `District_Code` varchar(2) NOT NULL,
  `Rural/Urban_Code` int(1) NOT NULL COMMENT 'Rural-1;Urban-2',
  `RO/SRO_Code` varchar(5) NOT NULL,
  `Number_of_Units` int(3) NOT NULL,
  `Status_of_Unit` int(2) NOT NULL COMMENT 'Refer to supplementary document for the meaning of the different codes',
  `Number_of_Working_Days_Manufacturing` int(3) NOT NULL,
  `Number_of_Working_Days_Non_Manufacturing` int(3) NOT NULL,
  `Number_of_Working_Days_Total` int(3) NOT NULL,
  `Cost_of_Production` int(12) NOT NULL,
  `Inflation/Multiplier_factor` decimal(4,4) NOT NULL COMMENT 'in 9999.9999 format',
  `Filler` varchar(109) NOT NULL COMMENT 'Padded with 0 or blank',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Identification Block for Official Use';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_B`
--

CREATE TABLE IF NOT EXISTS `BLOCK_B` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Type_of_Organisation` int(2) NOT NULL COMMENT 'Refer the supplementary document of the code lists',
  `Type_of_Ownership` int(1) NOT NULL COMMENT 'Refer the supplementary document of the code lists',
  `Total_number_of_units_of_the_company` int(4) NOT NULL,
  `Number_of_units_located_in_the_same_state` int(4) NOT NULL,
  `Year_of_initial_production` int(4) NOT NULL,
  `Accounting_Year_From` varchar(9) NOT NULL,
  `Accounting_Year_To` varchar(9) NOT NULL,
  `Number_of_months_of_operation` int(2) NOT NULL,
  `Does_the_unit_have_a_computerised_A/C_system` int(1) NOT NULL COMMENT 'Yes=1, No=2',
  `Can_the_unit_supply_ASI_data_in_Floppy` int(1) NOT NULL COMMENT 'Yes=1, No=2',
  `Filler` varchar(132) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='To be filled by factory owners';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_C`
--

CREATE TABLE IF NOT EXISTS `BLOCK_C` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_Number` int(2) NOT NULL COMMENT 'To be entered as printed in the schedule',
  `Opening_as_on(Col3)` int(12) NOT NULL,
  `Due_to_Revaluation(Col4)` int(12) NOT NULL,
  `Actual_Addition(Col5)` int(12) NOT NULL,
  `Deduction_and_adjustment_during_the_year(Col6)` int(12) NOT NULL,
  `Closing_as_on(Col7)` int(12) NOT NULL COMMENT 'Sum of columns 3,4,5,6',
  `Up_to_year_beginning(Col8)` int(12) NOT NULL,
  `Provided_during_the_year(Col9)` int(12) NOT NULL,
  `Up_to_year_end(Col10)` int(12) NOT NULL COMMENT 'Sum of columns 8,9',
  `Opening_as_on(Col11)` int(12) NOT NULL COMMENT 'Column 3 minus column 8',
  `Closing_as_on(Col12)` int(12) NOT NULL COMMENT 'Column 7 minus column 10',
  `Filler` varchar(47) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_D`
--

CREATE TABLE IF NOT EXISTS `BLOCK_D` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_Number` int(2) NOT NULL COMMENT 'To be entered as printed in the schedule',
  `Opening(Col3)` int(12) NOT NULL COMMENT 'In Rupees',
  `Closing(Col4)` int(12) NOT NULL COMMENT 'In Rupees',
  `Filler` varchar(143) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital and Loans';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_E`
--

CREATE TABLE IF NOT EXISTS `BLOCK_E` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_Number` int(2) NOT NULL COMMENT 'To be entered as printed in the schedule',
  `Mandays_Worked_Manufacturing` int(8) NOT NULL,
  `Mandays_Worked_Nonmanufacturing` int(8) NOT NULL,
  `Mandays_Worked_Total` int(10) NOT NULL,
  `Average_Number_of_Persons_Worked` int(8) NOT NULL,
  `Number_of_Mandays_paid_for` int(10) NOT NULL,
  `Wages/salaries` int(12) NOT NULL COMMENT 'In Rupees',
  `Bonus` int(12) NOT NULL COMMENT 'In Rupees',
  `Contribution_to_Provident_Fund_and_other_funds` int(12) NOT NULL COMMENT 'In Rupees',
  `Workmen_&_Staff_Welfare_Expenses` int(12) NOT NULL COMMENT 'In Rupees',
  `Filler` varchar(75) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment and Labour Cost';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_F`
--

CREATE TABLE IF NOT EXISTS `BLOCK_F` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Work_done_by_others` int(12) NOT NULL COMMENT 'Item1',
  `Repair_&_maintenance_of_Building` int(12) NOT NULL COMMENT 'Item2i',
  `Repair_&_maintenance_of_Plant_&_Machinery` int(12) NOT NULL COMMENT 'Item2ii',
  `Repair_&_maintenance_of_Pollution_control_equipment` int(12) NOT NULL COMMENT 'Item2iii',
  `Repair_&_maintenance_of_Other_fixed_assets` int(12) NOT NULL COMMENT 'Item2iv',
  `Operating_expenses` int(12) NOT NULL COMMENT 'Item3',
  `Non_Operating_expenses` int(12) NOT NULL COMMENT 'Item4',
  `Insurance_Charges` int(12) NOT NULL COMMENT 'Item5',
  `Rent_paid_for_Plant_&_Machinery_&_other_Fixed_assets` int(12) NOT NULL COMMENT 'Item6',
  `Total_expenses` int(12) NOT NULL COMMENT 'Item7=Sum of items 1 to 6',
  `Rent_paid_for_Buildings` int(12) NOT NULL COMMENT 'Item8',
  `Rent_paid_for_land_on_lease_or_royalties_on_mines,quarries_etc.` int(12) NOT NULL COMMENT 'Item9',
  `Interest_paid` int(12) NOT NULL COMMENT 'Item10',
  `Purchase_value_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL COMMENT 'Item11',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Expenses';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_G`
--

CREATE TABLE IF NOT EXISTS `BLOCK_G` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Income_from_services` int(12) NOT NULL COMMENT 'Item1',
  `Variation_in_stock_of_semifinished_goods` int(12) NOT NULL COMMENT 'Item1',
  `Value_in_electricity_generated_and_sold` int(12) NOT NULL COMMENT 'Item3',
  `Value_of_own_construction` int(12) NOT NULL COMMENT 'Item4',
  `Net_balance_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL COMMENT 'Item5',
  `Rent_received_for_Plant_&_Machinery_&_other_fixed_assets` int(12) NOT NULL COMMENT 'Item6',
  `Total_receipts` int(12) NOT NULL COMMENT 'Item7=Sum of Items 1 to 6',
  `Rent received_for_building` int(12) NOT NULL COMMENT 'Item8',
  `Rent_received_for_land_on_lease_or_royalties_on_mines_etc.` int(12) NOT NULL COMMENT 'Item9',
  `Interest_received` int(12) NOT NULL COMMENT 'Item10',
  `Sale_value_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL COMMENT 'Item11',
  `Filler` varchar(37) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Output/Receipts';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_H`
--

CREATE TABLE IF NOT EXISTS `BLOCK_H` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_Number` int(2) NOT NULL,
  `Item_Code` int(5) NOT NULL COMMENT 'Refer to ASICC Codes',
  `Unit_of_quantity(Code)` int(3) NOT NULL,
  `Quantity_Consumed` decimal(12,3) NOT NULL COMMENT 'As 999999999999.999',
  `Purchase_Value` int(12) NOT NULL COMMENT 'In Rupees',
  `Rate_per_unit` decimal(11,3) NOT NULL COMMENT 'in Rs.0.00; As 999999999999.99',
  `Filler` varchar(116) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Input Items-Indigenous items consumed';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_I`
--

CREATE TABLE IF NOT EXISTS `BLOCK_I` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_Number` int(2) NOT NULL,
  `Item_Code` int(5) NOT NULL COMMENT 'Refer to ASICC Codes',
  `Unit_of_quantity_code` int(3) NOT NULL,
  `Quantity_Consumed` decimal(12,3) NOT NULL COMMENT 'As 999999999999.999',
  `Purchase_Value_at_delivery` int(12) NOT NULL COMMENT 'In Rupees',
  `Rate_per_unit` decimal(12,2) NOT NULL COMMENT 'In Rs.0.00, As 999999999999.99',
  `Filler` varchar(116) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Input items-directly imported items only(consumed)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK_J`
--

CREATE TABLE IF NOT EXISTS `BLOCK_J` (
  `Year` varchar(2) NOT NULL COMMENT '06 for ASI 2005-06',
  `Block_Code` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL COMMENT 'Block-A, Item 1',
  `Serial_Number` int(2) NOT NULL,
  `Item_Code` int(5) NOT NULL COMMENT 'Refer to ASICC Codes',
  `Unit_of_quantity(Code)` int(3) NOT NULL,
  `Quantity_Manufactured` decimal(12,3) NOT NULL COMMENT 'As 99999999999.999',
  `Quantity_Sold` decimal(12,3) NOT NULL COMMENT 'As 99999999999.999',
  `Purchase_Value` int(12) NOT NULL COMMENT 'In Rupees',
  `Gross_Sale_Value` int(12) NOT NULL COMMENT 'In Rupees',
  `Excise_Duty` int(12) NOT NULL,
  `Sales_Tax` int(12) NOT NULL,
  `Others` int(12) NOT NULL,
  `Total` int(12) NOT NULL,
  `Per_unit_net_sale_value` decimal(12,2) NOT NULL COMMENT 'In Rupees; As 999999999999.99; [Col 7-Col 11/Col 6]',
  `Exfactory_value_of_output` int(12) NOT NULL COMMENT 'In Rupees; Col 12 multiplied by column 5',
  `Filler` varchar(40) NOT NULL COMMENT 'Padded with zero or blank',
  PRIMARY KEY (`DSL`,`Block_Code`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Products and by-products (Manufactured by the unit)';
