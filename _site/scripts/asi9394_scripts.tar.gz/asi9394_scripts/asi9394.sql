-- Copyright 2012 Centre for Economic Studies and Planning (CESP)
-- This script was written by Sakshi Jain (jainsakshi2016 at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
--
-- Database: `ASI_93_94`
--
DROP DATABASE IF EXISTS ASI_93_94;
CREATE DATABASE ASI_93_94;
USE ASI_93_94;

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK1_RC11`
--

CREATE TABLE IF NOT EXISTS `BLOCK1_RC11` (
  `Industry` varchar(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `FOD_RSL` int(5) NOT NULL,
  `Permanent_Serial_Number` varchar(5) NOT NULL,
  `Number_of_Units` int(3) NOT NULL,
  `State/District/Block_Code` varchar(6) NOT NULL,
  `FOD_Region_Code` varchar(5) NOT NULL,
  `Rural/Urban/Metropolitan_Code` int(1) NOT NULL,
  `Backward_Area_Code` int(1) NOT NULL,
  `Year_of_Initial_Production` int(4) NOT NULL,
  `Type_of_Organisation` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Type_of_Ownership` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Type_of_Management` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Whether_ancillary_unit` int(1) NOT NULL COMMENT 'Yes-1; No-2',
  `Whether_registered` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Accounting_Year_Closing` varchar(6) NOT NULL,
  `Months_of_operation` int(2) NOT NULL,
  `Type_of_power_used` int(1) NOT NULL COMMENT 'Refer to the supplementary document containing ASI Codes',
  `Open/Closed_Code` int(1) NOT NULL,
  `Number_of_Records_Block4` int(2) NOT NULL,
  `Number_of_Records_Block5` int(1) NOT NULL,
  `Number_of_Records_Block7` int(1) NOT NULL,
  `Number_of_Records_Block8` int(1) NOT NULL,
  `Number_of_Records_Block9` int(1) NOT NULL,
  `Number_of_Records_Block10` int(1) NOT NULL,
  `Number_of_Records_Block11` int(1) NOT NULL,
  `Number_of_Records_Block12` int(1) NOT NULL,
  `Number_of_Records_Block13` int(2) NOT NULL,
  `Number_of_Records_Block13A` int(2) NOT NULL,
  `Number_of_Records_Block13B` int(2) NOT NULL,
  `Number_of_Records_Block14` int(2) NOT NULL,
  `Number_of_Records_Block14A` int(1) NOT NULL,
  `Number_of_Records_Total` int(3) NOT NULL,
  `Filler` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='General Information';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK4_RC040`
--

CREATE TABLE IF NOT EXISTS `BLOCK4_RC040` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Sub_Record_Code` int(3) NOT NULL,
  `Opening(Gross)` int(11) NOT NULL,
  `Addition_by_revaluation` int(11) NOT NULL,
  `Addition_new` int(11) NOT NULL,
  `Deduction` int(11) NOT NULL,
  `Depreciation_Beginning` int(11) NOT NULL,
  `Depreciation_During` int(11) NOT NULL,
  `Sold_or_Discarded` int(11) NOT NULL,
  `Opening(Net)` int(11) NOT NULL,
  `Closing(Net)` int(11) NOT NULL,
  `Filler` varchar(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fixed Assets';

-- --------------------------------------------------------


-- Table structure for table `BLOCK4A_RC040_SRC014`

CREATE TABLE IF NOT EXISTS `BLOCK4A_RC040_SRC014` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Sub_Record_Code` int(3) NOT NULL,
  `P&M_Undepreciated_Opening` int(11) NOT NULL,
  `P&M_Leased_in_opening` int(11) NOT NULL,
  `P&M_Leased_out_opening` int(11) NOT NULL,
  `P&M_Total_opening` int(11) NOT NULL,
  `P&M_Undepreciated_Closing` int(11) NOT NULL,
  `P&M_Leased_in_closing` int(11) NOT NULL,
  `P&M_Leased_out_closing` int(11) NOT NULL,
  `P&M_Total_closing` int(11) NOT NULL,
  `Filler` varchar(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Plant & Machinery';



-- --------------------------------------------------------

--
-- Table structure for table `BLOCK5_RC051`
--

CREATE TABLE IF NOT EXISTS `BLOCK5_RC051` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Raw_materials_&_components` int(11) NOT NULL,
  `Fuels_&_lubricants` int(11) NOT NULL,
  `Spares,stores_&_others` int(11) NOT NULL,
  `Semi_finished_goods` int(11) NOT NULL,
  `Finished_goods` int(11) NOT NULL,
  `Total_inventory` int(11) NOT NULL,
  `Filler` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital & Loans, Opening Balance (Column 3)';

-- -------------------------------------------------------------

-- Table structure for table `BLOCK5_RC052`

CREATE TABLE IF NOT EXISTS `BLOCK5_RC052` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Cash_in_hand_&_bank` int(11) NOT NULL,
  `Sundry_debtors` int(11) NOT NULL,
  `Other_current_assets` int(11) NOT NULL,
  `Sundry_creditors` int(11) NOT NULL,
  `Overdrafts_etc` int(11) NOT NULL,
  `Other_current_liabilities` int(11) NOT NULL,
  `Working_capital(*)` int(11) NOT NULL COMMENT '(*)For negative value, "_" sign is to be entered as the left-most character',
  `Outstanding_loans` int(11) NOT NULL,
  `Filler` varchar(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital (contd) Opening Balance';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK5_RC053`
--

CREATE TABLE IF NOT EXISTS `BLOCK5_RC053` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Raw_materials_&_components` int(11) NOT NULL,
  `Fuels_&_lubricants` int(11) NOT NULL,
  `Spares,stores_&_others` int(11) NOT NULL,
  `Semi_finished_goods` int(11) NOT NULL,
  `Finished_goods` int(11) NOT NULL,
  `Total_inventory` int(11) NOT NULL,
  `Filler` varchar(43) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital & Loans, Closing Balance (Column 4)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK5_RC054`
--

CREATE TABLE IF NOT EXISTS `BLOCK5_RC054` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Cash_in_hand_&_bank` int(11) NOT NULL,
  `Sundry_debtors` int(11) NOT NULL,
  `Other_current_assets` int(11) NOT NULL,
  `Sundry_creditors` int(11) NOT NULL,
  `Overdrafts_etc` int(11) NOT NULL,
  `Other_current_liabilities` int(11) NOT NULL,
  `Working_capital(*)` int(11) NOT NULL COMMENT '(*)For negative value, "_" sign is to be entered as the left-most character',
  `Outstanding_loan` int(11) NOT NULL,
  `Filler` varchar(21) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Working Capital (contd) Closing Balance';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC071`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC071` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Employment_through_contractors` int(11) NOT NULL,
  `Supervisory_&_managerial_staff` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment, Manufacturing Days (column 3)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC072`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC072` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Employment_through_contractors` int(11) NOT NULL,
  `Supervisory_&_managerial_staff` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment, Non-Manufacturing Days (column 4)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC073`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC073` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Men` int(11) NOT NULL,
  `Women` int(11) NOT NULL,
  `Children` int(11) NOT NULL,
  `Employment_through_contractors` int(11) NOT NULL,
  `Supervisory_&_managerial_staff` int(11) NOT NULL,
  `Other_employees` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment, Total Days (column 5)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK7_RC074`
--

CREATE TABLE IF NOT EXISTS `BLOCK7_RC074` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Men` int(7) NOT NULL,
  `Women` int(7) NOT NULL,
  `Children` int(7) NOT NULL,
  `Employment_through_contractors` int(7) NOT NULL,
  `Supervisory_&_managerial_staff` int(7) NOT NULL,
  `Other_employees` int(7) NOT NULL,
  `Working_proprietors` int(7) NOT NULL,
  `Unpaid_family_workers` int(7) NOT NULL,
  `If_co-operative_etc` int(7) NOT NULL,
  `Total` int(7) NOT NULL,
  `Number_of_manufacturing_days` int(7) NOT NULL,
  `Total_number_of_working_days` int(7) NOT NULL,
  `Total_number_of_shifts` int(7) NOT NULL,
  `Length_of_shifts` int(7) NOT NULL,
  `Filler` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Employment(contd.)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK8_RC081`
--

CREATE TABLE IF NOT EXISTS `BLOCK8_RC081` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Wages_&_salaries_workers` int(10) NOT NULL,
  `Bonus_Workers` int(10) NOT NULL,
  `Contribution_to_PF_workers` int(10) NOT NULL,
  `Welfare_expense_workers` int(10) NOT NULL,
  `Total_labour_cost_workers` int(10) NOT NULL,
  `Wages_&_salaries_supervisory_staff` int(10) NOT NULL,
  `Bonus_supervisory_staff` int(10) NOT NULL,
  `Contribution_to_PF_supervisory_staff` int(10) NOT NULL,
  `Welfare_expenses_supervisory_staff` int(10) NOT NULL,
  `Total_labour_cost_supervisory_staff` int(10) NOT NULL,
  `Filler` varchar(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Labour Cost';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK8_RC082`
--

CREATE TABLE IF NOT EXISTS `BLOCK8_RC082` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Wages_&_salaries_others` int(10) NOT NULL,
  `Bonus_Others` int(10) NOT NULL,
  `Contribution_to_PF_others` int(10) NOT NULL,
  `Welfare_expense_others` int(10) NOT NULL,
  `Total_labour_cost_others` int(10) NOT NULL,
  `Wages_&_salaries_total` int(10) NOT NULL,
  `Bonus_total` int(10) NOT NULL,
  `Contribution_to_PF_total` int(10) NOT NULL,
  `Welfare_expenses_total` int(10) NOT NULL,
  `Total_labour_cost_total` int(10) NOT NULL,
  `Filler` varchar(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Labour Cost (contd.)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK9_RC091`
--

CREATE TABLE IF NOT EXISTS `BLOCK9_RC091` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Item_Code_2` varchar(4) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` varchar(4) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Item_code_4` varchar(4) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `Filler` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Fuels, electricity etc. consumed';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK10_RC101`
--

CREATE TABLE IF NOT EXISTS `BLOCK10_RC101` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Work_done_by_others` int(10) NOT NULL,
  `Repair_&_maintenance_Machinery` int(10) NOT NULL,
  `Repair_&_maintenance_Building` int(10) NOT NULL,
  `Repair_&_Maintenance_Others` int(10) NOT NULL,
  `Inward_Freight_etc.` int(10) NOT NULL,
  `Rates_&_Taxes` int(10) NOT NULL,
  `Postage,Telephone_etc` int(10) NOT NULL,
  `Insurance_charges` int(10) NOT NULL,
  `Banking_charges` int(10) NOT NULL,
  `Printing_&_stationery` int(10) NOT NULL,
  `Filler` varchar(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Expenditure';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK10_RC102`
--

CREATE TABLE IF NOT EXISTS `BLOCK10_RC102` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Miscellaneous` int(10) NOT NULL,
  `Total` int(10) NOT NULL,
  `Rent_of_land_etc` int(10) NOT NULL,
  `Rent_for_Building` int(10) NOT NULL,
  `Rent_for_P&M` int(10) NOT NULL,
  `Rent_for_other_assets` int(10) NOT NULL,
  `Total_rent` int(10) NOT NULL,
  `Interest` int(10) NOT NULL,
  `Purchase_value_of_goods_sold` int(10) NOT NULL,
  `Own_construction_labour_cost` int(10) NOT NULL,
  `Filler` varchar(9) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Expenditure (contd)';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK11_RC111`
--

CREATE TABLE IF NOT EXISTS `BLOCK11_RC111` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Own_construction_others` int(10) NOT NULL,
  `Own_construction_total` int(10) NOT NULL,
  `Work_done_for_others` int(10) NOT NULL,
  `Receipt_for_non_industrial_services` int(10) NOT NULL,
  `Variation_of_stock_of_semi_finished_goods(*)` int(10) NOT NULL COMMENT '(*)For negative value, "_" sign is to be entered as the left-most character',
  `Value_of_electricity_sold` int(10) NOT NULL,
  `Value_of_own_construction` int(10) NOT NULL,
  `Total(*)` int(10) NOT NULL COMMENT '(*)For negative value, "_" sign is to be entered as the left-most character',
  `Sale_value_of_goods_sold_etc` int(10) NOT NULL,
  `Filler` varchar(19) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Other Output/Receipts';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK12_RC121`
--

CREATE TABLE IF NOT EXISTS `BLOCK12_RC121` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Electricity_purchased` int(11) NOT NULL,
  `Electricity_generated` int(11) NOT NULL,
  `Electricity_sold` int(11) NOT NULL,
  `Electricity_consumed` int(12) NOT NULL,
  `Filler` varchar(65) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Electricity';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK13A_RC132`
--

CREATE TABLE IF NOT EXISTS `BLOCK13A_RC132` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1a` int(11) NOT NULL,
  `Value_1a` int(11) NOT NULL,
  `Qty_1b` int(11) NOT NULL,
  `Value_1b` int(11) NOT NULL,
  `Item_Code_2` varchar(4) NOT NULL,
  `Qty_2a` int(11) NOT NULL,
  `Value_2a` int(11) NOT NULL,
  `Qty_2b` int(11) NOT NULL,
  `Value_2b` int(11) NOT NULL,
  `Filler` varchar(13) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Industrial Components etc.';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK13A_RC133`
--

CREATE TABLE IF NOT EXISTS `BLOCK13A_RC133` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Item_Code_2` varchar(4) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` varchar(4) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Item_code_4` varchar(4) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `Filler` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Imported Materials';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK13_RC131`
--

CREATE TABLE IF NOT EXISTS `BLOCK13_RC131` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Item_code_1` varchar(4) NOT NULL,
  `Qty_1` int(11) NOT NULL,
  `Value_1` int(11) NOT NULL,
  `Item_Code_2` varchar(4) NOT NULL,
  `Qty_2` int(11) NOT NULL,
  `Value_2` int(11) NOT NULL,
  `Item_code_3` varchar(4) NOT NULL,
  `Qty_3` int(11) NOT NULL,
  `Value_3` int(11) NOT NULL,
  `Item_code_4` varchar(4) NOT NULL,
  `Qty_4` int(11) NOT NULL,
  `Value_4` int(11) NOT NULL,
  `Filler` varchar(5) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Materials etc. consumed';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK14A_RC142`
--

CREATE TABLE IF NOT EXISTS `BLOCK14A_RC142` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sales_tax` int(11) NOT NULL,
  `Transport_charges` int(11) NOT NULL,
  `Commission` int(11) NOT NULL,
  `Rebates` int(11) NOT NULL,
  `Other` int(11) NOT NULL,
  `Total` int(11) NOT NULL,
  `Filler` varchar(32) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Distributive expenses etc.';

-- --------------------------------------------------------

--
-- Table structure for table `BLOCK14_RC141`
--

CREATE TABLE IF NOT EXISTS `BLOCK14_RC141` (
  `Industry` int(4) NOT NULL,
  `Running_Serial_Number` int(5) NOT NULL,
  `State` int(2) NOT NULL COMMENT 'Refer to the State Code List',
  `Scheme` int(1) NOT NULL COMMENT 'Census-1; Sample-2',
  `Record_Category` varchar(3) NOT NULL,
  `Link_Code` int(3) NOT NULL,
  `Item_code` varchar(4) NOT NULL,
  `Quantity_manufactured` int(11) NOT NULL,
  `Quantity_sold` int(11) NOT NULL,
  `Gross_sale_value` int(11) NOT NULL,
  `Excise_duty` int(11) NOT NULL,
  `Sales_tax` int(11) NOT NULL,
  `Distributive_Expenses_other` int(11) NOT NULL,
  `Distributive_Expenses_total` int(11) NOT NULL,
  `Itemwise_NSV_unit` int(11) NOT NULL,
  `Itemwise_Ex_factory_Value` int(11) NOT NULL,
  `Filler` varchar(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Products and by-products etc.';
