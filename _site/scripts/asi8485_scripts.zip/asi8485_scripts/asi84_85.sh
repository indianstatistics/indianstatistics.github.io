# Copyright 2012 Centre for Economic Studies and Planning (CESP)
#
# This script was written by Sakshi Jain (jainsakshi2016 at
# gmail dot com) as part of an initiative directed by Vikas Rawal
# (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
# and ASI data. This initiative is supported by the CAS programme of
# CESP.
# 
# To run this, you need to specify below the ip address/hostname of
# the mysql server, the mysql username and mysql password.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

#! /bin/sh
server=127.0.0.1 # ip address/hostname of the mysql server 
username="username"   # mysql user name
pass="password"    # password of the mysql user
time_start=`date +%s`
echo "Scripts to read ASI 1984-85 data called at `date`"
rm -Rf ../csv786pibs
mkdir ../csv786pibs 
./asi8485.awk ../Data/ASI84_85.TXT
echo "Data parsed into csv files for each level at `date`"
mysql --host=$server --user=$username --password=$pass < asi8485.sql
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC011.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC041.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC042.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC043.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC044.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC045.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC046.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC047.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC048.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC051.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC052.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC061.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC062.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC081.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC082.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC083.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC084.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC085.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC086.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC087.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC088.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC101.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC111.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC112.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC121.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC091.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC131.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC133.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC132.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC143.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC141.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, ASI_84_85 --local ../csv786pibs/RC142.csv
echo "Mysql database created at `date`"
echo "Now cleaning up..."
rm -Rf ../csv786pibs
time_end=`date +%s`
time_exec=`expr $(( $time_end - $time_start ))`
echo "The script took $time_exec seconds to finish."
