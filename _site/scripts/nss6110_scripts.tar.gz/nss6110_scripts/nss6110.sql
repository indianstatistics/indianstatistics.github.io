-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


--
-- Database: `NSS_61_10`
--
DROP DATABASE IF EXISTS NSS_61_10;
CREATE DATABASE NSS_61_10;
USE NSS_61_10;


-- --------------------------------------------------------

--
-- Table structure for table `Level_01`
--

CREATE TABLE IF NOT EXISTS `Level_01` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '01 Generated',
  `Filler` varchar(5) NOT NULL COMMENT '00000 Generated',
  `Informant_Serial_Number` varchar(2) NOT NULL,
  `Response_Code` int(1) NOT NULL COMMENT 'informant : co-operative and capable-1, co-operative but not capable-2, busy-3, reluctant-4, others-9',
  `Survey_Code` int(1) NOT NULL COMMENT 'household surveyed : original-1, substitute-2, casualty-3',
  `Substitution_Code` int(1) NOT NULL COMMENT 'informant busy-1, members away from home-2, informant non-cooperative-3, others-9',
  `Date_of_Survey` varchar(6) NOT NULL COMMENT 'ddmmyy',
  `Date_of_Despatch` varchar(6) NOT NULL COMMENT 'ddmmyy',
  `Time_to_canvass_Schedule10` int(3) NOT NULL COMMENT 'In minutes',
  `Time_to_canvass_Block9_of_Schedule10` int(3) NOT NULL COMMENT 'In minutes',
  `Household_size` int(2) NOT NULL,
  `Principal_Industry_NIC_98_Code` varchar(5) NOT NULL,
  `Principal_Occupation_NCO_68_Code` varchar(3) NOT NULL,
  `Household_type` int(1) NOT NULL COMMENT 'For rural areas: Self-employed in non-agriculture-1, Agricultural labour-2, Other labour-3, Self-employed  in agriculture-4, Others-9. For urban areas: Self-employed-1, Regular wage/salary earning-2, Casual labour-3, Others-9',
  `Religion` int(1) NOT NULL COMMENT 'Hinduism-1, Islam-2, Christianity -3, Sikhism-4, Jainism-5, Buddhism-6, Zoroastrianism-7, Others-9',
  `Social_group` int(1) NOT NULL COMMENT 'Scheduled Tribe-1, Scheduled Caste-2, Other Backward Class-3, Others-9',
  `Land_owned` int(9) NOT NULL,
  `Land_possessed` int(9) NOT NULL,
  `Land_cultivated` int(9) NOT NULL,
  `Public_Works_Male` int(2) NOT NULL,
  `Public_Works_Female` int(2) NOT NULL,
  `MPCE` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(8) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Informant_Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Blocks 1, 2 and 3';

-- --------------------------------------------------------

--
-- Table structure for table `Level_02`
--

CREATE TABLE IF NOT EXISTS `Level_02` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '02 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number_of_loan` varchar(2) NOT NULL,
  `Nature_of_loan` int(1) NOT NULL COMMENT 'hereditary loan-1, loan contracted in cash-2, loan contracted in kind-3, loan contracted partly in cash and partly in kind-4',
  `Source` int(1) NOT NULL COMMENT 'government-1, co-operative society-2, bank-3, employer/landlord-4, agricultural/professional money lender-5, shopkeeper/trader-6, relatives/friends-7, others-9',
  `Purpose` int(1) NOT NULL COMMENT 'household consumption: medical expenses-1, educational expenses-2, legal expenses-3, other expenses-4; marriage and other ceremonial expenses-5, purchase of land/construction of building-6, productive purpose-7, repayment of debt-8, others-9',
  `Amount_outstanding_including_interest` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(72) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number_of_loan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 3.1';

-- --------------------------------------------------------

--
-- Table structure for table `Level_03`
--

CREATE TABLE IF NOT EXISTS `Level_03` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '“61” Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '03 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Person_Serial_Number` varchar(2) NOT NULL,
  `Relation_to_head` int(1) NOT NULL COMMENT 'self-1, spouse of head-2, married child-3, spouse of married child-4, unmarried child-5, grandchild-6, father/mother/father-in-law/mother-in-law-7, brother/sister/brother-in-law/sister-in-law/other relatives-8, servants/employees/other non-relatives-9',
  `Sex` int(1) NOT NULL COMMENT 'Male-1, Female-2',
  `Age` int(3) NOT NULL COMMENT 'In years',
  `Marital_status` int(1) NOT NULL COMMENT 'never married-1, currently married-2, widowed-3, divorced/separated-4',
  `General_education` varchar(2) NOT NULL COMMENT 'not literate -01; literate without formal schooling: EGS/NFEC/AEC -02, TLC-03, others-04; Literate: below primary-05, primary-06, middle-07, secondary-08, higher secondary-10, diploma/certificate course-11, graduate-12, postgraduate and above-13',
  `Technical_Education` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Status_of_current_attendance` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Type_of_institution` int(1) NOT NULL COMMENT 'government-1, local body-2, private aided-3, private unaided-4, not known-5',
  `Registered_with_employment_exchange` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Vocational_training` int(1) NOT NULL COMMENT 'yes: receiving formal vocational training-1; received vocational training: formal-2, non-formal: hereditary-3, others-4;  did not receive any vocational training-5',
  `Field_of_training` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Duration_of_training` int(3) NOT NULL COMMENT 'In Weeks',
  `Source_Degree_diploma_certificate_received` int(2) NOT NULL COMMENT 'degree-1, diploma-2, certificate-3',
  `Whether_beneficiary_of_the_scheme_during_last_365_days` int(1) NOT NULL COMMENT 'yes: annapurna-1, ICDS-2, midday meal-3, food for work-4; no-5',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(60) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person_Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 4';

-- --------------------------------------------------------

--
-- Table structure for table `Level_04`
--

CREATE TABLE IF NOT EXISTS `Level_04` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '04 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Person_serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In years',
  `Usual_principal_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Usual_principal_activity_NIC_98_code` varchar(5) NOT NULL COMMENT 'Industry:5-digit code as per NIC-98',
  `Usual_principal_activity_NCO_68_code` varchar(3) NOT NULL COMMENT 'occupation: 3-digit code as per NCO-68',
  `Engaged_in_subsidiary_activity?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Location_of_workspace` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Enterprise_type` int(1) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Enterprise_uses_electricity?` int(1) NOT NULL COMMENT 'Yes-1, No-2, Not known-9',
  `Number_of_workers_in_enterprise` int(1) NOT NULL COMMENT 'less than 6-1, 6  to 9-2, 10 & above but less than 20-3, 20 & above-4, not known-9',
  `Type_of_job_contract` int(1) NOT NULL COMMENT 'no written  job contract -1; written job contract: for 1 year or less-2, more than 1 year to 3  years-3, more than 3 years-4',
  `Eligible_for_paid_leave?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Social_security_benefits_availability` int(1) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Method_of_payment` int(1) NOT NULL COMMENT 'regular monthly salary-1, regular weekly payment-2, daily payment-3, piece rate payment-4, others-5',
  `Availabilty_of_work` int(1) NOT NULL,
  `Suitable_for_NCO_68_Code` varchar(3) NOT NULL,
  `Participated_voluntarily` int(1) NOT NULL,
  `Industry_Group_NIC_98_Code` varchar(3) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(52) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person_serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 5.1';

-- --------------------------------------------------------

--
-- Table structure for table `Level_05`
--

CREATE TABLE IF NOT EXISTS `Level_05` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '05 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In years',
  `Usual_subsidiary_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Usual_subsidiary_activity_NIC_98_code` varchar(5) NOT NULL COMMENT 'Industry:5-digit code as per NIC-98',
  `Usual_subsidiary_activity_NCO_68_code` varchar(3) NOT NULL COMMENT 'occupation:3-digit code as per NCO-68',
  `Location_of_workspace` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Enterprise_uses_electricity?` int(1) NOT NULL COMMENT 'Yes-1, No-2, Not known-9',
  `Number_of_workers_in_enterprise` int(1) NOT NULL COMMENT 'less than 6-1, 6 to 9-2, 10 & above but less than 20-3, 20 & above-4, not known-9',
  `Type_of_job_contract` int(1) NOT NULL COMMENT 'no written  job contract-1; written job contract: for 1 year or less-2, more than 1 year to 3 years-3, more than 3 years-4',
  `Eligible_for_paid_leave` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Social_security_benefits_availability` int(1) NOT NULL COMMENT 'Refer to Schedule for comments',
  `Method_of_payment` int(1) NOT NULL COMMENT 'regular monthly salary-1, regular weekly payment-2, daily payment-3, piece rate payment-4, others-5',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(61) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 5.2';

-- --------------------------------------------------------

--
-- Table structure for table `Level_06`
--

CREATE TABLE IF NOT EXISTS `Level_06` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '06 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Person_serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In years',
  `Serial_number_of_activity` int(1) NOT NULL,
  `Status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `NIC_98_Code` varchar(2) NOT NULL COMMENT 'industry division: 2-digit division codes as per NIC-98',
  `Operation_for_rural_areas_only` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Intensity_7th_day` int(2) NOT NULL,
  `Intensity_6th_day` int(2) NOT NULL,
  `Intensity_5th_day` int(2) NOT NULL,
  `Intensity_4th_day` int(2) NOT NULL,
  `Intensity_3rd_day` int(2) NOT NULL,
  `Intensity_2nd_day` int(2) NOT NULL,
  `Intensity_1st_day` int(2) NOT NULL,
  `Total_number_of_days_in_each_activity` int(2) NOT NULL,
  `Wage_&_Salary_Earnings_Cash` int(8) NOT NULL,
  `Wage_&_Salary_Earnings_Kind` int(8) NOT NULL,
  `Wage_&_Salary_Earnings_Total` int(8) NOT NULL,
  `Mode_of_payment` int(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Number_of_days_with_nominal_work` int(1) NOT NULL,
  `Current_weekly_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Current_weekly_activity_NIC_98` varchar(5) NOT NULL COMMENT 'industry: 5-digit code as per NIC-98',
  `Current_weekly_activity_NCO_68` varchar(3) NOT NULL COMMENT 'occupation: 3-digit code as per NCO-68',
  `Unemployed_on_all_7_days` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(19) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person_serial_number`,
`Serial_number_of_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 5.3';

-- --------------------------------------------------------

--
-- Table structure for table `Level_07`
--

CREATE TABLE IF NOT EXISTS `Level_07` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '07 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In Years',
  `Duration_spell_of_unemployment` int(1) NOT NULL COMMENT 'only 1 week-1,  more than 1 week to 2 weeks-2, more than 2 weeks to 1 month-3, more than 1 month to 2 months-4, more than 2 months to 3 months-5, more than 3 months to 6 months-6, more than 6 months to 12 months-7, more than 12 months–8',
  `Whether_ever_worked?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Last_employment_Duration` int(1) NOT NULL COMMENT 'only 1 month-1,  more than 1 month to 2 months-2, more than 2  months to 3 months-3, more than 3 months to 6 months-4, more than 6 months to 12 months-5, more than 12 months-6',
  `Last_employment_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Last_employment_NIC_98` varchar(2) NOT NULL,
  `Last_employment_NCO_68` varchar(3) NOT NULL,
  `Reason_for_break_in_employment` int(1) NOT NULL COMMENT 'loss of earlier job-1, quit earlier job-2, lay-off without pay-3, unit has closed down-4, lack of work in the enterprise (for self-employed persons)-5, lack of work in the area (for casual labour)-6, others-9',
  `Reason_for_quitting_the_job` int(1) NOT NULL COMMENT 'work was not remunerative enough-1, unpleasant environment-2, employer harsh-3, health hazard-4, to avail benefits of voluntary retirement-5, others-9',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(68) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 6';

-- --------------------------------------------------------

--
-- Table structure for table `Level_08`
--

CREATE TABLE IF NOT EXISTS `Level_08` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '08 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In Years',
  `Usual_principal_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Usual_subsidiary_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Full_time/part_time_work_during_last_365_days` int(1) NOT NULL COMMENT 'Full time-1, Part time-2',
  `Worked_more_or_less_regularly` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Number_of_months_without_work` int(2) NOT NULL,
  `Available_for_work?` int(1) NOT NULL COMMENT 'whether sought/available for work during those months:yes: on most days-1, on some days-2; no-3',
  `Made_any_efforts_to_get_work?` int(1) NOT NULL COMMENT 'yes: registered in employment exchange-1, other efforts-2;  no effort-3',
  `Employment_renumerative?` int(1) NOT NULL COMMENT 'Whether current earning from self-employment remunerative: Yes-1, No-2',
  `Amount_considered_renumerative` int(1) NOT NULL COMMENT 'less than or equal to Rs.1000-1, Rs.1001 to Rs.1500-2, Rs, 1501 to Rs. 2000-3, Rs.2001 to Rs.2500-4, Rs.2501 to Rs.3000-5, more than Rs.3000-6',
  `Available_for_additional_work?` int(1) NOT NULL COMMENT 'yes: on most days-1, on some days-2; no-3',
  `Reason1` int(1) NOT NULL COMMENT 'reason for seeking/available for additional work: to supplement income-1, not enough work-2, both-3, others-9',
  `Available_for_alternative_work?` int(1) NOT NULL COMMENT 'yes: on most days-1, on some days-2; no-3',
  `Reason2` int(1) NOT NULL COMMENT 'reason for seeking/available for alternative work: present work not remunerative enough-1, no job satisfaction-2, lack of job security-3, workplace too far-4, wants wage/salary job-5, others-9',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(64) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  `Autoid` int (1) NOT NULL auto_increment COMMENT 'Additional Primary Key',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`,`Autoid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 7.1';

-- --------------------------------------------------------

--
-- Table structure for table `Level_09`
--

CREATE TABLE IF NOT EXISTS `Level_09` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '09 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In Years',
  `Usual_principal_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Usual_subsidiary_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Union/Association` int(1) NOT NULL COMMENT 'Yes-1, No-2, Not known-9',
  `Member_of_union/association` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Nature_of_employment` int(1) NOT NULL COMMENT 'Permanent-1, Temporary-2',
  `Changed_work_activity_status` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Changed_last_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Changed_Industry` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Changed_last_Industry` varchar(2) NOT NULL COMMENT '2-digit codes as per NIC-98',
  `Changed_Occupation` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Changed_Last_Occupation` varchar(2) NOT NULL COMMENT '2-digit codes as per NCO-68',
  `Changed_Establishment` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Reason_for_last_change` int(1) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(62) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  `Autoid` int (1) NOT NULL auto_increment COMMENT 'Additional Primary Key',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`,`Autoid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 7.2';

-- --------------------------------------------------------

--
-- Table structure for table `Level_10`
--

CREATE TABLE IF NOT EXISTS `Level_10` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '10 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Person_Serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In Years',
  `Spend_time_on_domestic_duties` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Reason_thereof` int(1) NOT NULL COMMENT 'No other member to carry out the domestic duties-1, cannot afford hired help-2, for social and/or religious circumstances-3, others-9',
  `Reason_for_still_pursuing_domestic_duties` int(1) NOT NULL COMMENT 'Non-availability of work-1, by preference-2, others-9',
  `Maintainence_of_kitchen_gardens_etc` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Household_Poultry` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Free_collection_of_fish_fruits_etc` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Free_collection_of_firewood_etc` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Husking_of_paddy` int(1) NOT NULL COMMENT 'yes: commodities produced in own farm/free collection-1, commodities acquired otherwise-2; no-3',
  `Grinding_of_food_grains` int(1) NOT NULL COMMENT 'yes: commodities produced in own farm/free collection-1, commodities acquired otherwise-2; no-3',
  `Preparation_of_gur` int(1) NOT NULL COMMENT 'yes: commodities produced in own farm/free collection-1, commodities acquired otherwise-2; no-3',
  `Preservation_of_meat_and_fish` int(1) NOT NULL COMMENT 'yes: commodities produced in own farm/free collection-1, commodities acquired otherwise-2; no-3',
  `Making_baskets_and_mats` int(1) NOT NULL COMMENT 'yes: commodities produced in own farm/free collection-1, commodities acquired otherwise-2; no-3',
  `Preparation_of_cow_dung_as_fuel` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Sewing_weaving_tailoring_etc` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Tutoring_of_children` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Bring_water_from_outside_premises` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Rural_Bring_water_from_outside_village` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Rural_Distance` int(3) NOT NULL COMMENT 'If 1 in Previous Column, then distance in kilometres',
  `Willing_to_accept_work` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Nature_of_work_acceptable` int(1) NOT NULL COMMENT 'regular full time-1, regular part-time-2, occasional full time-3, occasional part-time-4',
  `Type_of_work_acceptable` int(1) NOT NULL COMMENT 'dairy-1, poultry-2, other animal husbandry-3, food processing-4, spinning and weaving-5, manufacturing wood and cane products-6, tailoring-7, leather goods manufacturing-8, others-9',
  `Requisite_skill` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Assistance_required` int(1) NOT NULL COMMENT 'no assistance-1;  yes: initial finance on easy terms-2, working finance facilities-3, easy availability of raw materials-4, assured market-5, training-6, accommodation-7, others-9',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(55) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  `Autoid` int (1) NOT NULL auto_increment COMMENT 'Additional Primary Key',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person_Serial_number`,`Autoid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 8';

-- --------------------------------------------------------

--
-- Table structure for table `Level_11`
--

CREATE TABLE IF NOT EXISTS `Level_11` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '61 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Stratum_Number` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '11 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` varchar(2) NOT NULL,
  `Value_of_consumption_last_30_days` int(8) NOT NULL,
  `Value_of_consumption_last_365_days` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(67) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `NSC` int(3) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SS` int(10) NOT NULL COMMENT 'Subsample-wise Design Based Weights',
  `MLT_SR` int(10) NOT NULL COMMENT 'Sub-round-wise subsample Combined Weights',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 9';
