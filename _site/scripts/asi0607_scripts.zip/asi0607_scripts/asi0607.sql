-- Copyright 2012 Centre for Economic Studies and Planning (CESP)
-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
--
-- Database: `ASI_06_07`
--
DROP DATABASE IF EXISTS ASI_06_07;
CREATE DATABASE ASI_06_07;
USE ASI_06_07;
-- --------------------------------------------------------
--
-- Table structure for table `A`
--
CREATE TABLE IF NOT EXISTS `A` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `PSL_No` varchar(5) NOT NULL,
  `Scheme_code` int(1) NOT NULL,
  `Industry_Code_as_per_Frame_(4_digit_level_of_NIC_04)` varchar(4) NOT NULL,
  `Ind_Code_as_per_Return_(5_digit_NIC_04)` varchar(5) NOT NULL,
  `State_Code` varchar(2) NOT NULL,
  `District_code` varchar(2) NOT NULL,
  `Rural/Urban_code` int(1) NOT NULL,
  `RO/SRO_code` varchar(5) NOT NULL,
  `No_of_units` int(3) NOT NULL,
  `Status_of_Unit_(Code_17_to_20_Extracted_data_from_ASI_06_07)` varchar(2) NOT NULL,
  `Number_of_working_days_(Manufacturing_days)` int(3) NOT NULL,
  `Number_of_working_days_(Non_Manufacturing_days)` int(3) NOT NULL,
  `Number_of_working_days_(Total)` int(3) NOT NULL,
  `Cost_of_Production` int(12) NOT NULL,
  `Inflation/Multiplier_factor` decimal(4,4) NOT NULL COMMENT 'In 9999.9999 format',
  `Padded_with_0_or_blank` varchar(109) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='IDENTIFICATION BLOCK FOR OFFICIAL USE';

-- --------------------------------------------------------

--
-- Table structure for table `B`
--

CREATE TABLE IF NOT EXISTS `B` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Type_of_organisation(code)` varchar(2) NOT NULL,
  `Type_of_ownership(code)` int(1) NOT NULL,
  `Total_number_of_units_the_company_has` int(4) NOT NULL,
  `How_many_units_located_in_the_same_state` int(4) NOT NULL,
  `Year_of_initial_production` int(4) NOT NULL,
  `Accounting_year_(From)` varchar(9) NOT NULL,
  `Accounting_year_(To)` varchar(9) NOT NULL,
  `Number_of_months_of_operation` int(2) NOT NULL,
  `Does_your_unit_have_computerised_A/C_system_(Yes_1_No_2)` int(1) NOT NULL,
  `Can_your_unit_supply ASI_data_in_Computer_Floppy_(Yes_1_No_2)` int(1) NOT NULL,
  `Padded_with_0_or_blank` varchar(132) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='FILLED BY OWNERS';

-- --------------------------------------------------------

--
-- Table structure for table `C`
--

CREATE TABLE IF NOT EXISTS `C` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Sl_No` varchar(2) NOT NULL,
  `Opening_as_on_1` int(12) NOT NULL,
  `Due_to_revaluation` int(12) NOT NULL,
  `Actual_addition` int(12) NOT NULL,
  `Deduction_&_adjustment_during_the_year` int(12) NOT NULL,
  `Closing_as_on_1` int(12) NOT NULL,
  `Up_to_year_beginning` int(12) NOT NULL,
  `Provided_during_the_year` int(12) NOT NULL,
  `Up_to_year_end` int(12) NOT NULL,
  `Opening_as_on_2` int(12) NOT NULL,
  `Closing_as _on_2` int(12) NOT NULL,
  `Padded_with_0_or_blank` varchar(47) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`,`Sl_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='FIXED ASSETS';

-- --------------------------------------------------------

--
-- Table structure for table `D`
--

CREATE TABLE IF NOT EXISTS `D` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Sl_No` varchar(2) NOT NULL,
  `Opening_(Rs)` int(12) NOT NULL,
  `Closing_(Rs)` int(12) NOT NULL,
  `Padded_with_0_or_blank` varchar(143) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`,`Sl_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='WORKING CAPITAL AND LOANS';

-- --------------------------------------------------------

--
-- Table structure for table `E`
--

CREATE TABLE IF NOT EXISTS `E` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Sl_No` int(2) NOT NULL,
  `Mandays_Worked_(Manufacturing)` int(8) NOT NULL,
  `Mandays_Worked_(Non_Manufacturing)` int(8) NOT NULL,
  `Mandays_Worked_(Total)` int(10) NOT NULL,
  `Average_Number_of_persons_worked` int(8) NOT NULL,
  `No_of_mandays_paid_for` int(10) NOT NULL,
  `Wages/salaries_(in_Rs)` int(12) NOT NULL,
  `Bonus_(in_Rs)` int(12) NOT NULL,
  `Contribution_to_Provident_Fund_and_other_funds` int(12) NOT NULL,
  `Workmen_&_Staff_Welfare_Expenses` int(12) NOT NULL,
  `Padded_with_0_or_blank` varchar(75) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`,`Sl_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='EMPLOYMENT AND LABOUR COST';

-- --------------------------------------------------------

--
-- Table structure for table `F`
--

CREATE TABLE IF NOT EXISTS `F` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Work_done_by_others` int(12) NOT NULL,
  `Repair_&_maintenance_of_Building` int(12) NOT NULL,
  `Repair_&_maintenance_of_Plant_&_Machinery` int(12) NOT NULL,
  `Repair_& _aintenance_of_Pollution_control_equipment` int(12) NOT NULL,
  `Repair_&_maintenance_of_Other_fixed_assets` int(12) NOT NULL,
  `Operating_expenses` int(12) NOT NULL,
  `Non_operating_expenses` int(12) NOT NULL,
  `Insurance_Charges` int(12) NOT NULL,
  `Rent_paid_for_Plant_&_Machinery_and_other_Fixed_assets` int(12) NOT NULL,
  `Total_expenses_(1_to_6)` int(12) NOT NULL,
  `Rent_paid_for_Buildings` int(12) NOT NULL,
  `Rent_paid_for_land_on_lease_or_royalties_on_mines_quarries_etc` int(12) NOT NULL,
  `Interest_paid` int(12) NOT NULL,
  `Purchase_value_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='OTHER EXPENSES';

-- --------------------------------------------------------

--
-- Table structure for table `G`
--

CREATE TABLE IF NOT EXISTS `G` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Income_from_services` int(12) NOT NULL,
  `Variation_in_stock_of_semi_finished_goods` int(12) NOT NULL,
  `Value_in_electricity_generated_and_sold` int(12) NOT NULL,
  `Value_of_own_construction` int(12) NOT NULL,
  `Net_balance_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL,
  `Rent_received_for_Plant_&_Machinery_and_other_fixed_assets` int(12) NOT NULL,
  `Total_receipts_(1_to_6)` int(12) NOT NULL,
  `Rent_received_for_building` int(12) NOT NULL,
  `Rent_received_for_land_on_lease_or_royalties_on_mines_quarries` int(12) NOT NULL,
  `Interest_received` int(12) NOT NULL,
  `Sale_value_of_goods_sold_in_the_same_condition_as_purchased` int(12) NOT NULL,
  `Padded_with_0_or_blank` varchar(37) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='OTHER OUTPUT/RECEIPTS';

-- --------------------------------------------------------

--
-- Table structure for table `H`
--

CREATE TABLE IF NOT EXISTS `H` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Sl_No` varchar(2) NOT NULL,
  `Item_code_(ASICC)` varchar(5) NOT NULL,
  `Unit_of_quantity_(code)` int(3) NOT NULL,
  `Quantity_consumed` decimal(12,3) NOT NULL COMMENT 'As 99999999999.999',
  `Purchase_value_(in_Rs)` int(12) NOT NULL,
  `Rate_per_unit_(in_Rs)` decimal(12,2) NOT NULL COMMENT 'as 999999999999.99',
  `Padded_with_0_or_blank` varchar(116) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`,`Sl_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='INPUT ITEMS-Indigenous items consumed';

-- --------------------------------------------------------

--
-- Table structure for table `I`
--

CREATE TABLE IF NOT EXISTS `I` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Sl_No` varchar(2) NOT NULL,
  `Item_code_(ASICC)` varchar(5) NOT NULL,
  `Unit_of_quantity_(code)` int(3) NOT NULL,
  `Quantity_consumed` decimal(12,3) NOT NULL COMMENT 'As 99999999999.999',
  `Purchase_value_at_delivery_(in_Rs)` int(12) NOT NULL,
  `Rate_per_unit_(in_Rs)` decimal(12,2) NOT NULL COMMENT 'As 999999999999.99',
  `Padded_with_0_or_blank` varchar(116) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`,`Sl_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='INPUTS-Directly imported items only (consumed)';

-- --------------------------------------------------------

--
-- Table structure for table `J`
--

CREATE TABLE IF NOT EXISTS `J` (
  `Year` varchar(2) NOT NULL,
  `Block` varchar(2) NOT NULL,
  `DSL` int(5) NOT NULL,
  `Sl_No` varchar(2) NOT NULL,
  `Item_code_(ASICC)` varchar(5) NOT NULL,
  `Unit_of_quantity_(code)` int(3) NOT NULL,
  `Quantity_manufactured` decimal(12,3) NOT NULL COMMENT 'As 99999999999.999',
  `Quantity_sold` decimal(12,3) NOT NULL COMMENT 'As 99999999999.999',
  `Gross_sale_value_(Rs)` int(12) NOT NULL,
  `Excis_duty` int(12) NOT NULL,
  `Sales_Tax` int(12) NOT NULL,
  `Others` int(12) NOT NULL,
  `Total` int(12) NOT NULL,
  `Per_unit_net_sale_value_(Rs)` decimal(12,2) NOT NULL COMMENT 'As 999999999999.99',
  `Ex_factory_value_of_output_(Rs)` int(12) NOT NULL,
  `Padded_with_0_or_blank` varchar(40) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`,`Sl_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='PRODUCTS & BY-PRODUCTS (Manufactured by unit)';

