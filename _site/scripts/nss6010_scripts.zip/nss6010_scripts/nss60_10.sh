# Copyright 2012 Centre for Economic Studies and Planning (CESP)
#
# This script was written by Shreshtha Saraswat (shreshtha.saraswat at
# gmail dot com) as part of an initiative directed by Vikas Rawal
# (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
# and ASI data. This initiative is supported by the CAS programme of
# CESP.
# 
# To run this, you need to specify below the ip address/hostname of
# the mysql server, the mysql username and mysql password.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

#! /bin/sh
server=127.0.0.1 # ip address/hostname of the mysql server 
username="USERNAME"   # mysql user name
pass="PASSWORD"    # password of the mysql user
time_start=`date +%s`
echo "Scripts to read NSS 60th round Schedule 10 data called at `date`"
rm -Rf ../csv4623zoe
mkdir ../csv4623zoe
./level01.awk ../Data/*.TXT
./level02.awk ../Data/*.TXT
./level03.awk ../Data/*.TXT
./level04.awk ../Data/*.TXT
./level05.awk ../Data/*.TXT
./level06.awk ../Data/*.TXT
echo "Data parsed into csv files for each level at `date`"
mysql --host=$server --user=$username --password=$pass < nss6010.sql
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_60_10 --local ../csv4623zoe/Level_01.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_60_10 --local ../csv4623zoe/Level_02.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_60_10 --local ../csv4623zoe/Level_03.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_60_10 --local ../csv4623zoe/Level_04.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_60_10 --local ../csv4623zoe/Level_05.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_60_10 --local ../csv4623zoe/Level_06.csv
echo "Mysql database created at `date`"
echo "Now cleaning up..."
rm -Rf ../csv4623zoe
time_end=`date +%s`
time_exec=`expr $(( $time_end - $time_start ))`
echo "The script took $time_exec seconds to finish."
