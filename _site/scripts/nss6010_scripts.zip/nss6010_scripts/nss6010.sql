-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.


SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


--
-- Database: `NSS_60_10`
--
DROP DATABASE IF EXISTS NSS_60_10;
CREATE DATABASE NSS_60_10;
USE NSS_60_10;

-- --------------------------------------------------------

--
-- Table structure for table `Level_01`
--

CREATE TABLE IF NOT EXISTS `Level_01` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '60 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Schedule_Type` int(1) NOT NULL COMMENT '0 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '01 Generated',
  `Filler` varchar(5) NOT NULL COMMENT '00000 Generated',
  `Informant_Serial_Number` varchar(2) NOT NULL,
  `Response_Code` int(1) NOT NULL COMMENT 'informant : co-operative and capable-1, co-operative but not capable-2, busy-3, reluctant-4, others-9',
  `Survey_Code` int(1) NOT NULL COMMENT 'household surveyed : original-1, substitute-2, casualty-3',
  `Substitution_Code` int(1) NOT NULL COMMENT 'informant busy-1, members away from home-2, informant non-cooperative-3, others-9',
  `Date_of_Survey` varchar(6) NOT NULL COMMENT 'ddmmyy',
  `Date_of_Despatch` varchar(6) NOT NULL COMMENT 'ddmmyy',
  `Time_to_canvass` int(3) NOT NULL COMMENT 'In minutes',
  `Household_size` int(2) NOT NULL,
  `Principal_Industry_NIC_98_Code` varchar(5) NOT NULL,
  `Principal_Industry_NCO_68_Code` varchar(3) NOT NULL,
  `Household_type` int(1) NOT NULL COMMENT 'For rural areas: self-employed in non-agriculture-1, agricultural labour-2, other labour-3, self-employed  in agriculture-4, others-9. For urban areas: self-employed-1, regular wage/salary earning-2, casual labour-3, others-9',
  `Religion` int(1) NOT NULL COMMENT 'Hinduism-1, Islam-2, Christianity-3, Sikhism-4, Jainism-5, Buddhism-6, Zoroastrianism-7, others-9',
  `Social_group` int(1) NOT NULL COMMENT 'scheduled tribe-1, scheduled caste-2, other backward class-3, others-9',
  `Land_possessed_area_in_hectares` varchar(2) NOT NULL COMMENT 'Less than 0.005=01, 0.005-0.01=02, 0.02-0.20=03, 0.21-0.40=04, 0.41.00=05, 1.01.00=06, 2.01.00=07, 3.01.00=08, 4.01.00=10, 6.01.00=11, Greater than 8.00=12',
  `MPCE` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(41) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `NSC` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `MLT` int(10) NOT NULL COMMENT 'Combined Schedule Type Weight',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Informant_Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Blocks 1, 2 and 3';

-- --------------------------------------------------------

--
-- Table structure for table `Level_02`
--

CREATE TABLE IF NOT EXISTS `Level_02` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '60 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Schedule_Type` int(1) NOT NULL COMMENT '0 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '02 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_Number` varchar(2) NOT NULL,
  `Relation_to_head` int(1) NOT NULL COMMENT 'self-1, spouse of head-2, married child-3, spouse of married child-4, unmarried child-5, grandchild-6, father/mother/father-in-law/mother-in-law-7, brother/sister/brother-in-law/sister-in-law/other relatives-8, servants/employees/other non-relatives-9',
  `Sex` int(1) NOT NULL COMMENT 'Male-1, Female-2',
  `Age` int(3) NOT NULL COMMENT 'In years',
  `Marital_status` int(1) NOT NULL COMMENT 'never married-1, currently married-2, widowed-3, divorced/separated-4',
  `General_education` varchar(2) NOT NULL COMMENT 'not literate-01, literate without formal schooling-02, literate but below primary-03, primary-04, middle-05, secondary-06, higher secondary-07,  diploma/certificate course-08,  graduate-10,  postgraduate and above-11',
  `Technical_Education` int(1) NOT NULL COMMENT 'No technical education-1;Technical degree in agriculture/engineering/technology/medicine, etc.-2; Diploma or certificate in: agriculture-3, engineering/technology-4, medicine-5, crafts-6; Other subjects-9',
  `Usual_activity_principal_status` varchar(2) NOT NULL COMMENT 'Refer to the Schedule',
  `Usual_activity_NIC_98_code` varchar(5) NOT NULL,
  `Usual_activity_NCO_68_code` varchar(3) NOT NULL,
  `Engaged_in_subsidiary_activity` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Subsidiary_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Subsidiary_NIC_98_Code` varchar(5) NOT NULL,
  `Subsidiary_NCO_68_Code` varchar(3) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(54) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `NSC` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `MLT` int(10) NOT NULL COMMENT 'Combined Schedule Type Weight',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 4';

-- --------------------------------------------------------

--
-- Table structure for table `Level_03`
--

CREATE TABLE IF NOT EXISTS `Level_03` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '60 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Schedule_Type` int(1) NOT NULL COMMENT '0 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '03 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Person_serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In years',
  `Serial_number_of_activity` int(1) NOT NULL,
  `Status` int(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `NIC_98_Code` varchar(2) NOT NULL,
  `Operation_for_rural_areas_only` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Intensity_7th_day` int(2) NOT NULL,
  `Intensity_6th_day` int(2) NOT NULL,
  `Intensity_5th_day` int(2) NOT NULL,
  `Intensity_4th_day` int(2) NOT NULL,
  `Intensity_3rd_day` int(2) NOT NULL,
  `Intensity_2nd_day` int(2) NOT NULL,
  `Intensity_1st_day` int(2) NOT NULL,
  `Total_number_of_days_in_each_activity` int(2) NOT NULL,
  `Wage_&_Salary_Earnings_Cash` int(8) NOT NULL,
  `Wage_&_Salary_Earnings_Kind` int(8) NOT NULL,
  `Wage_&_Salary_Earnings_Total` int(8) NOT NULL,
  `Current_weekly_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule',
  `Current_weekly_activity_NIC_98` varchar(5) NOT NULL,
  `Current_weekly_activity_NCO_68` varchar(3) NOT NULL,
  `Unemployed_on_all_7_days` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(23) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `NSC` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `MLT` int(10) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `ID` int(1) NOT NULL auto_increment COMMENT 'Additional Primary Key',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person_serial_number`, `ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 5';

-- --------------------------------------------------------

--
-- Table structure for table `Level_04`
--

CREATE TABLE IF NOT EXISTS `Level_04` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '60 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Schedule_Type` int(1) NOT NULL COMMENT '0 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '04 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` varchar(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In Years',
  `Duration_spell_of_unemployment` int(1) NOT NULL COMMENT 'only 1 week-1,  more than 1 week to 2 weeks-2, more than 2 weeks to 1 month-3, more than 1 month to 2 months-4, more than 2 months to 3 months-5, more than 3 months to 6 months-6, more than 6 months to 12 months-7, more than 12 months',
  `Whether_ever_employed` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Last_employment_Duration` int(1) NOT NULL COMMENT 'only 1 week-1,  more than 1 week to 2 weeks-2, more than 2 weeks to 1 month-3, more than 1 month to 2 months-4, more than 2 months to 3 months-5, more than 3 months to 6 months-6, more than 6 months to 12 months-7, more than 12 months',
  `Last_employment_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule for codes',
  `Last_employment_NIC_98` varchar(5) NOT NULL,
  `Last_employment_NCO_68` varchar(3) NOT NULL,
  `Reason_for_break_in_employment` int(1) NOT NULL COMMENT 'lay-off without pay-1, unit closed down-2, quit job-3, loss of job due to other reasons-4, lack of work in the enterprise (for self-employed persons)-5, lack of work in the area (for casual labour)-6, others-9',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(67) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `NSC` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `MLT` int(10) NOT NULL COMMENT 'Combined Schedule Type Weight',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 6';

-- --------------------------------------------------------

--
-- Table structure for table `Level_05`
--

CREATE TABLE IF NOT EXISTS `Level_05` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '60 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Schedule_Type` int(1) NOT NULL COMMENT '0 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '05 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` int(2) NOT NULL,
  `Age` int(3) NOT NULL COMMENT 'In Years',
  `Sex` int(1) NOT NULL COMMENT 'Male-1, Female-2',
  `Usual_principal_activity_status` varchar(2) NOT NULL COMMENT 'Refer to Schedule',
  `Usual_principal_activity_industry_code` varchar(5) NOT NULL,
  `Usual_principal_activity_occupation_code` varchar(3) NOT NULL,
  `Vocational_training` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Serial_number_of_training` int(1) NOT NULL,
  `Field_of_training` varchar(2) NOT NULL,
  `Institution_of_training` varchar(2) NOT NULL,
  `Duration_of_training` int(3) NOT NULL COMMENT 'In Weeks',
  `Degree_diploma_certificate_received` int(1) NOT NULL COMMENT 'degree-1, diploma-2, certificate-3',
  `Useful_in_present_job` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Helpful_in_another_economic_activity` int(1) NOT NULL COMMENT 'helpful in taking up self-employment activity-1, helpful in taking up wage/salaried employment-2, not helpful-3, unlikely to be used-5',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(58) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `NSC` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `MLT` int(10) NOT NULL COMMENT 'Combined Schedule Type Weight',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`,`Serial_number_of_training`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 7';

-- --------------------------------------------------------

--
-- Table structure for table `Level_06`
--

CREATE TABLE IF NOT EXISTS `Level_06` (
  `Centre_code_Round_and_Shift` varchar(3) NOT NULL,
  `FSU_Serial_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '60 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Schedule_Type` int(1) NOT NULL COMMENT '0 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum` varchar(2) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '06 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` varchar(2) NOT NULL,
  `Value_of_consumption_last_30_days` int(8) NOT NULL,
  `Value_of_consumption_last_365_days` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(68) NOT NULL,
  `NSS` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `NSC` int(3) NOT NULL COMMENT 'Combined Schedule Type Weight',
  `MLT` int(10) NOT NULL COMMENT 'Combined Schedule Type Weight',
  PRIMARY KEY (`FSU_Serial_Number`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 8';
