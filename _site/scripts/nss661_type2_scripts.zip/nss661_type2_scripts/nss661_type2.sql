-- Copyright 2012 Centre for Economic Studies and Planning (CESP)
-- This script was written by Abdul Raheem Shariq (shariqazeez at
-- gmail dot com)  and Sakshi Jain (jainsakshi2016 at gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
-- GNU General Public License for more details.
-- You should have received a copy of the GNU General Public License
-- along with this program. If not, see <http://www.gnu.org/licenses/>.
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
--
-- Database: `NSS_66_1_Type2`
--
DROP DATABASE IF EXISTS NSS_66_1_Type2;
CREATE DATABASE NSS_66_1_Type2;
USE NSS_66_1_Type2;
-- --------------------------------------------------------
--
-- Table structure for table `LEVEL_01`
--
CREATE TABLE IF NOT EXISTS `LEVEL_01` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_number` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_No` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL,
  `Filler` varchar(5) NOT NULL,
  `Sl_No_of_informant` varchar(2) NOT NULL,
  `Response_Code` int(1) NOT NULL COMMENT 'co_operative_and_capable(1)__co_operative_but_not_capable(2)__busy(3)__reluctant(4)__others(9)',
  `Survey_Code` int(1) NOT NULL,
  `Substitution_Code` varchar(1) NOT NULL,
  `Date_of_Survey` varchar(6) NOT NULL,
  `Date_of_Despatch` varchar(6) NOT NULL,
  `Time_to_canvass_mins` int(3) NOT NULL,
  `remark_in_block_14/15` int(1) NOT NULL,
  `remark_elsewhere` int(1) NOT NULL,
  `Get_enough_food_everyday` int(1) NOT NULL,
  `Months_not_getting_enough_fooda` int(2) NOT NULL,
  `Months_not_getting_enough_foodb` int(2) NOT NULL,
  `Months_not_getting_enough_foodc` int(2) NOT NULL,
  `Months-not getting enough_foodd` int(2) NOT NULL,
  `Months_not_getting_enough_foode` int(2) NOT NULL,
  `Months_not_getting_enough_foodf` int(2) NOT NULL,
  `Months_not_getting_enough_foodg` int(2) NOT NULL,
  `Months_not_getting_enough_foodh` int(2) NOT NULL,
  `Months_not_getting_enough_foodi` int(2) NOT NULL,
  `Months_not_getting_enough_foodj` int(2) NOT NULL,
  `Months_not_getting_enough_foodk` int(2) NOT NULL,
  `Information_actually_obtained` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(37) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_number`,`Second_Stage_Stratum`,`HHS_No`,`Level`,` Sl_No_of_informant`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_02`
--

CREATE TABLE IF NOT EXISTS `LEVEL_02` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_number` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_No` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL,
  `Filler` varchar(5) NOT NULL,
  `HH_Size` int(2) NOT NULL,
  `NIC_2004_Code_5_digit` varchar(5) NOT NULL,
  `NCO_2004_Code_3_digit` varchar(3) NOT NULL,
  `HH_type` int(1) NOT NULL COMMENT 'self_employed_in_non_agriculture(1)__agricultural_labour(2)__other_labour(3)__self_employed_in_agriculture(4)__others(9)',
  `Religion` int(1) NOT NULL COMMENT 'Hinduism(1)__Islam(2)__Christianity(3)__Sikhism(4)__Jainism(5)__Buddhism(6)__Zoroastrianism(7)__others(9)',
  `Social_Group` int(1) NOT NULL COMMENT 'Scheduled_Tribes(1)__Scheduled_Castes(2)__Other_Backward_Classes(3)__others(9)',
  `Whether_owns_any_land` int(1) NOT NULL COMMENT 'yes(1)__no(2)',
  `Type_of_land_owned` int(1) NOT NULL COMMENT 'homestead_only(1)__homestead_and_other_land(2)__other_land_only(3)',
  `Land_Owned` int(8) NOT NULL COMMENT 'in_0.000_hectares',
  `Land_Leased_in` int(8) NOT NULL COMMENT 'in_0.000_hectares',
  `Land_Neither_owned_nor_leased_in` int(8) NOT NULL COMMENT 'in_0.000_hectares',
  `Land_Leased_out` int(8) NOT NULL COMMENT 'in_0.000_hectares',
  `Land_Total_possessed` int(8) NOT NULL COMMENT 'in_0.000_hectares',
  `During_july08_june_09_Cultivated` int(8) NOT NULL COMMENT 'in_0.000_hectares',
  `During_july08_june_09_Irrigated` int(8) NOT NULL COMMENT 'in_0.000_hectares',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(12) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
   PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_number`,`Second_Stage_Stratum`,`HHS_No`,`Level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_03`
--

CREATE TABLE IF NOT EXISTS `LEVEL_03` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_number` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_No` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL,
  `Filler` varchar(5) NOT NULL,
  `Cooking_code` varchar(2) NOT NULL COMMENT 'coke_coal_and_charcoal(1)__firewood_and_chips(2)__LPG(3)__gobar_gas(4)__dung_cake(5)__kerosene(6)___electricity(7)_others(9)__no_cooking_arrangement(8)',
  `Lighting_code` int(1) NOT NULL COMMENT 'kerosene(1)__other_oil(2)__gas(3)__candle(4)__electricity(5)__others(9)__no_lighting_arrangement(6)',
  `Dwelling_unit_code` int(1) NOT NULL COMMENT 'owned(1)__hired(2)__no_dwelling_unit(3)__others(9)',
  `Regular_salary_income_?` int(1) NOT NULL COMMENT 'yes(1)__no(2)',
  `Performmed_Ceremony_During_Last_30_days_?` int(1) NOT NULL COMMENT 'yes(1)__no(2)',
  `Meals_seved_to_non_hhld_members_during_last_30_days` int(4) NOT NULL,
  `Internet_access` int(1) NOT NULL COMMENT 'yes(1)__no(2)',
  `MPCE` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(64) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_number`,`Second_Stage_Stratum`,`HHS_No`,`Level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_04`
--

CREATE TABLE IF NOT EXISTS `LEVEL_04` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_number` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_No` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL,
  `Filler` varchar(3) NOT NULL,
  `Person_Srl_No` varchar(2) NOT NULL,
  `Relation` int(1) NOT NULL COMMENT 'self(1)__Spouse_of_head(2)__married_child(3)__spouse_of_married_child(4)__unmarried_child(5)__grandchild(6)__father/mother_or_father/mother_in_law(7)__brother_sister_brotherinlaw_sisterinlaw_other_relative(8)__servant_employees_other_non_relative(9)',
  `Sex` int(1) NOT NULL COMMENT 'male(1)__female(2)',
  `Age` int(3) NOT NULL COMMENT 'years',
  `Marital_Status` int(1) NOT NULL COMMENT 'never_married(1)__currently_married(2)__widowed(3)__divorced_seperated(4)',
  `Education` varchar(2) NOT NULL COMMENT 'not literate(01)__literate_without_formal_schooling[EGS/NFEC/AEC(2)__through_TLC(3)__others(4)]_kiterate_with_formal_schooling[below_primary(5)__primary(6)__middle(7)__secondary(8)__higher_secondary(10__diploma_certificate_course(11)__graduate(12)__post_',
  `Days_Stayed_away_during_last_30_days` int(2) NOT NULL,
  `No_of_Meals_per_day` int(1) NOT NULL,
  `Meals_School` int(2) NOT NULL,
  `Meals_Employer` int(2) NOT NULL,
  `Meals_Others` int(2) NOT NULL,
  `Meals_Payment` int(2) NOT NULL,
  `Meals_At_Home` int(2) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(62) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
   PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_number`,`Second_Stage_Stratum`,`HHS_No`,`Level`,`Person_Srl_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_05`
--

CREATE TABLE IF NOT EXISTS `LEVEL_05` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` varchar(5) NOT NULL,
  `Round` varchar(2) NOT NULL,
  `Schedule_Number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_number` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_No` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL,
  `Filler` varchar(2) NOT NULL,
  `Item_Code` varchar(3) NOT NULL,
  `Home_Produce_Quantity` int(9) NOT NULL,
  `Home_Produce_Value` int(8) NOT NULL,
  `Total_Consumption_Quantity` int(9) NOT NULL,
  `Total_Consumption_Value` int(8) NOT NULL,
  `Source_Code` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(48) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_number`,`Second_Stage_Stratum`,`HHS_No`,`Level`,`Item_Code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_06`
--

CREATE TABLE IF NOT EXISTS `LEVEL_06` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` varchar(5) NOT NULL,
  `Round` varchar(2) NOT NULL,
  `Schedule_number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` int(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_no.` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_NO.` varchar(2) NOT NULL,
  `Level(06_Generated)` varchar(2) NOT NULL,
  `Filler(00_Generated)` int(2) NOT NULL,
  `Item_code` varchar(3) NOT NULL COMMENT 'For Item codes refer to the Schedule_66_1.0_type-2.doc, page no. 13,14',
  `Last_365_days_quantity` int(9) NOT NULL,
  `Last_365_days_value` int(8) NOT NULL,
  `Special_characters_for_OK_Stamp` varchar(2) NOT NULL,
  `Blank` varchar(66) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_no.`,`Second_Stage_Stratum`,`HHS_NO.`,`Level(06_Generated)`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_07`
--

CREATE TABLE IF NOT EXISTS `LEVEL_07` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` varchar(5) NOT NULL,
  `Round` varchar(2) NOT NULL,
  `Schedule_number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_no.` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_NO.` varchar(2) NOT NULL,
  `Level(07_Generated)` varchar(2) NOT NULL,
  `Filler(00_Generated)` int(2) NOT NULL,
  `Item_code` varchar(3) NOT NULL COMMENT 'For Item codes refer to Schedule_66_1.0_type-2.doc, page no. 15',
  `value` int(8) NOT NULL,
  `Special_characters_for_OK_Stamp` int(2) NOT NULL,
  `Blank` varchar(75) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_no.`,`Second_Stage_Stratum`,`HHS_NO.`,`Level(07_Generated)`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_08`
--

CREATE TABLE IF NOT EXISTS `LEVEL_08` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` varchar(5) NOT NULL,
  `Round` varchar(2) NOT NULL,
  `Schedule_number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_no.` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_NO.` varchar(2) NOT NULL,
  `Level(08_Generated)` varchar(2) NOT NULL,
  `Filler(00_Generated)` int(2) NOT NULL,
  `Item_code` varchar(3) NOT NULL COMMENT 'For Item codes refer to Schedule_66_1.0_type-2.doc, page no. 16,17',
  `value` int(8) NOT NULL,
  `Special_characters_for_OK_Stamp` int(2) NOT NULL,
  `Blank` varchar(75) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_no.`,`Second_Stage_Stratum`,`HHS_NO.`,`Level(08_Generated)`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_09`
--

CREATE TABLE IF NOT EXISTS `LEVEL_09` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` varchar(5) NOT NULL,
  `Round` varchar(2) NOT NULL,
  `Schedule_number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_no.` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_NO.` varchar(2) NOT NULL,
  `Level(09_Generated)` varchar(2) NOT NULL,
  `Filler(00_Generated)` int(2) NOT NULL,
  `Item_code` varchar(3) NOT NULL COMMENT 'For Item codes refer to Schedule_66_1.0_type-2.doc, page no. 18-22',
  `Whether_possesses?` int(1) NOT NULL COMMENT 'yes-1, no-2',
  `First_hand_purchase_number` int(3) NOT NULL,
  `whether_hire_purchased` int(1) NOT NULL COMMENT 'yes-1, no-2',
  `First_hand_purchase_Value` int(8) NOT NULL,
  `Cost_raw_material_service_&_repair` int(8) NOT NULL,
  `Second_hand_purchase_Number` int(3) NOT NULL,
  `Second_hand_purchase_Value` int(8) NOT NULL,
  `Total_expenditure` int(8) NOT NULL,
  `Special_characters_for_OK_Stamp` int(2) NOT NULL,
  `Blank` varchar(43) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_no.`,`Second_Stage_Stratum`,`HHS_NO.`,`Level(09_Generated)`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_10`
--

CREATE TABLE IF NOT EXISTS `LEVEL_10` (
  `Round_and_Centre_code` varchar(3) NOT NULL,
  `LOT/FSU_number` varchar(5) NOT NULL,
  `Round` varchar(2) NOT NULL,
  `Schedule_number` varchar(3) NOT NULL,
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` varchar(1) NOT NULL,
  `Schedule_type` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_Sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL,
  `Hamlet_Group/Sub_Block_no.` int(1) NOT NULL,
  `Second_Stage_Stratum` int(1) NOT NULL,
  `HHS_NO.` varchar(2) NOT NULL,
  `Level(10_Generated)` varchar(2) NOT NULL,
  `Filler(000_Generated)` int(3) NOT NULL,
  `Serial_Number` varchar(2) NOT NULL,
  `value` int(10) NOT NULL,
  `Special_characters_for_OK_Stamp` int(2) NOT NULL,
  `Blank` varchar(73) NOT NULL,
`NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
    PRIMARY KEY (`LOT/FSU_number`,`Hamlet_Group/Sub_Block_no.`,`Second_Stage_Stratum`,`HHS_NO.`,`Level(10_Generated)`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


