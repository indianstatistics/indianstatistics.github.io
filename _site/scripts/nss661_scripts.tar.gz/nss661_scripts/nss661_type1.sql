-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program. If not, see <http://www.gnu.org/licenses/>.

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `NSS_66_1_Type1`
--
DROP DATABASE IF EXISTS NSS_66_1_Type1;
CREATE DATABASE NSS_66_1_Type1;
USE NSS_66_1_Type1;


-- --------------------------------------------------------


DROP TABLE IF EXISTS `LEVEL_01`;
CREATE TABLE IF NOT EXISTS `LEVEL_01` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '02 Generated',
  `Filler` varchar(5) NOT NULL,
  `Serial_number_of_informant` varchar(2) NOT NULL,
  `Response_code` int(1) NOT NULL COMMENT 'Informant: Co-operative and capable -1, Co-operative but not capable-2, Busy-3, Reluctant-4, Others-9',
  `Survey_Code` int(1) NOT NULL COMMENT 'original–1, substitute–2, casualty-3',
  `Substitution_code` varchar(1) NOT NULL COMMENT 'Informant busy-1, Members away from home-2, Informant non-cooperative-3, Others-9',
  `Date_of_survey` varchar(6) NOT NULL COMMENT 'ddmmyy',
  `Date_of_despatch` varchar(6) NOT NULL COMMENT 'ddmmyy',
  `Time_to_canvass` int(3) NOT NULL COMMENT 'In minutes',
  `Remark_in_block_13/14` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Remark_elsewhere` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(61) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Serial_number_of_informant`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Blocks 1 and 2';

DROP TABLE IF EXISTS `LEVEL_02`;
CREATE TABLE IF NOT EXISTS `LEVEL_02` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '02 Generated',
  `Filler` varchar(5) NOT NULL COMMENT '00000 Generated',
  `Household_Size` int(2) NOT NULL,
  `NIC_2004_Code` varchar(5) NOT NULL COMMENT '5-digit',
  `NCO_2004_Code` varchar(3) NOT NULL COMMENT '3-digit',
  `Household_Type` int(1) NOT NULL COMMENT 'For rural areas: self-employed in non-agriculture-1, agricultural labour-2, other labour-3, self-employed in agriculture-4, others-9. For urban areas: self-employed-1, regular wage/salary earning-2, casual labour-3, Others-9',
  `Religion` int(1) NOT NULL COMMENT 'Hinduism-1, Islam-2, Christianity-3, Sikhism-4, Jainism-5, Buddhism-6, Zoroastrianism-7, Others-9',
  `Social_Group` int(1) NOT NULL COMMENT 'Scheduled Tribes-1, Scheduled Castes-2, Other Backward Classes-3, Others-9',
  `Whether_owns_any_land` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Type_of_land_owned` int(1) NOT NULL COMMENT 'Homestead only–1, Homestead and other land–2, Other land only–3',
  `Land_Owned` int(8) NOT NULL,
  `Land_leased_in` int(8) NOT NULL,
  `Land_neither_owned_nor_leased_in` int(8) NOT NULL,
  `Land_leased_out` int(8) NOT NULL,
  `Land_total_possessed` int(8) NOT NULL,
  `During_July08_June09_Cultivated` int(8) NOT NULL,
  `During_July08_June09_Irrigated` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(12) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 3 (Household Characteristics): Items 1 to 15';

DROP TABLE IF EXISTS `LEVEL_03`;
CREATE TABLE IF NOT EXISTS `LEVEL_03` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '03 Generated',
  `Filler` varchar(5) NOT NULL COMMENT '00000 Generated',
  `Cooking_code` varchar(2) NOT NULL COMMENT 'coke, coal-01, firewood and chips-02, LPG-03, gobar gas-04, dung cake-05, charcoal-06, kerosene-07, electricity-08, others-09, no cooking arrangement-10',
  `Lighting_code` int(1) NOT NULL COMMENT 'kerosene-1, other oil-2, gas-3, candle-4, electricity-5, others-9, no lighting arrangement-6',
  `Dwelling_unit_code` int(1) NOT NULL COMMENT 'Owned-1, Hired-2, No dwelling unit-3, Others-9',
  `Regular_salary_income` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Perform_ceremony` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Meals_served_to_non_household_members` int(4) NOT NULL,
  `Internet_access` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `MPCE_(URP)` int(8) NOT NULL,
  `MPCE_(MRP)` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(56) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 3(Household characteristics):Items 16 to 24';

DROP TABLE IF EXISTS `LEVEL_04`;
CREATE TABLE IF NOT EXISTS `LEVEL_04` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '04 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Person_serial_number` varchar(2) NOT NULL,
  `Relation` int(1) NOT NULL COMMENT 'self-1, spouse of head-2, married child-3, spouse of married child-4, unmarried child-5, grandchild-6, father/mother/father-in-law/mother-in-law-7, Brother/sister/brother-in-law/sister-in-law/other relatives-8, servants/employees/other non-relatives-9',
  `Sex` int(1) NOT NULL COMMENT 'Male-1, Female-2',
  `Age` int(3) NOT NULL,
  `Marital_status` int(1) NOT NULL COMMENT 'never married–1, currently married–2, widowed–3, divorced/separated–4',
  `Education` varchar(2) NOT NULL COMMENT 'Refer to the schedule for codes',
  `Days_stayed_away` int(2) NOT NULL,
  `Number_of_meals_per_day` int(1) NOT NULL,
  `Meals_school` int(2) NOT NULL,
  `Meals_employer` int(2) NOT NULL,
  `Meals_others` int(2) NOT NULL,
  `Meals_by_payment` int(2) NOT NULL,
  `Meals_at_home` int(2) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(62) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Person_serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 4:Demographic & other particulars of household members';

DROP TABLE IF EXISTS `LEVEL_05`;
CREATE TABLE IF NOT EXISTS `LEVEL_05` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '05 Generated',
  `Filler` varchar(2) NOT NULL COMMENT '00 Generated',
  `Item_code` varchar(3) NOT NULL,
  `Home_produce_quantity` int(9) NOT NULL,
  `Home_produce_value` int(8) NOT NULL,
  `Total_consumption_quantity` int(9) NOT NULL,
  `Total_consumption_value` int(8) NOT NULL,
  `Source_code` int(1) NOT NULL COMMENT 'only purchase-1, only home-grown stock-2, both purchase and home-grown stock-3, only free collection-4, only exchange of goods and services-5, only gifts/ charities-6, others-9',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(48) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Blocks 5.1,5.2(Consumption-food,pan,tobacco & intoxicants)';

DROP TABLE IF EXISTS `LEVEL_06`;
CREATE TABLE IF NOT EXISTS `LEVEL_06` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '06 Generated',
  `Filler` varchar(2) NOT NULL COMMENT '00 Generated',
  `Item_code` varchar(3) NOT NULL,
  `Last_30_days_quantity` int(9) NOT NULL,
  `Last_30_days_value` int(8) NOT NULL,
  `Last_365_days_quantity` int(9) NOT NULL,
  `Last_365_days_value` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(49) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Blocks 7 and 8';

DROP TABLE IF EXISTS `LEVEL_07`;
CREATE TABLE IF NOT EXISTS `LEVEL_07` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '07 Generated',
  `Filler` varchar(2) NOT NULL COMMENT '00 Generated',
  `Item_code` varchar(3) NOT NULL,
  `Last_30_days_value` int(8) NOT NULL,
  `Last_365_days_value` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(67) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 9: Expenditure on education & medical goods & services';

DROP TABLE IF EXISTS `LEVEL_08`;
CREATE TABLE IF NOT EXISTS `LEVEL_08` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL, 
  `Level` varchar(2) NOT NULL COMMENT '08 Generated',
  `Filler` varchar(2) NOT NULL COMMENT '00 Generated',
  `Item_code` varchar(3) NOT NULL,
  `Value` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(75) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 10';

DROP TABLE IF EXISTS `LEVEL_09`;
CREATE TABLE IF NOT EXISTS `LEVEL_09` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '09 Generated',
  `Filler` varchar(2) NOT NULL COMMENT '00 Generated',
  `Item_code` varchar(3) NOT NULL,
  `Whether_possesses?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `First_hand_purchase_number(30_days)` int(3) NOT NULL,
  `Whether_hire_purchased_30_days` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `First_hand_purchase_value_last_30_days` int(8) NOT NULL,
  `Cost_raw_material_service_and_repair_1` int(8) NOT NULL,
  `Second_hand_purchase_number_last_30_days` int(8) NOT NULL,
  `Total_expenditure_last_30_days` int(8) NOT NULL,
  `First_hand_purchase_number(365_days)` int(3) NOT NULL,
  `Whether_hire_purchased_365_days` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `First_hand_purchase_value(365_days)` int(8) NOT NULL,
  `Cost_raw_material_service_and_repair_2` int(8) NOT NULL,
  `Second_hand_purchase_number_last_365_days` int(3) NOT NULL,
  `Second_hand_purchase_value_last_365_days` int(8) NOT NULL,
  `Total_expenditure_last_365_days` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(7) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Item_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 11';

DROP TABLE IF EXISTS `LEVEL_10`;
CREATE TABLE IF NOT EXISTS `LEVEL_10` (
  `Round_and_centre_code` varchar(3) NOT NULL,
  `LOT/FSU_Number` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` varchar(3) NOT NULL COMMENT '010 Generated',
  `Sample` int(1) NOT NULL,
  `Sector` int(1) NOT NULL,
  `State_Region` varchar(3) NOT NULL,
  `District` varchar(2) NOT NULL,
  `Stratum_Number` varchar(2) NOT NULL,
  `Sub_Stratum` int(1) NOT NULL,
  `Schedule_Type` int(1) NOT NULL COMMENT '1 Generated',
  `Sub_round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` varchar(4) NOT NULL COMMENT 'Refer to Appendix 1 to Instructions to field staff',
  `Hamlet_Group/Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum` int(1) NOT NULL,
  `HHS_Number` varchar(2) NOT NULL,
  `Level` varchar(2) NOT NULL COMMENT '10 Generated',
  `Filler` varchar(3) NOT NULL COMMENT '000 Generated',
  `Serial_Number` varchar(2) NOT NULL COMMENT 'size against serial no.45 is in whole number',
  `Value` int(10) NOT NULL COMMENT 'Figures in Rs. except for MPCE(URP) & MPCE(MRP) against Sr.No.47 & 48 respectively, which are in assumed two places of decimal or paisa i.e. Rs.0.00',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` varchar(73) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  PRIMARY KEY (`LOT/FSU_Number`,`Hamlet_Group/Sub_block_number`,`Second_stage_stratum`,`HHS_Number`,`Level`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 12: Summary of consumer expenditure';
