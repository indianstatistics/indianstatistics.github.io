-- Copyright 2012 Centre for Economic Studies and Planning (CESP)
-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.
-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.
-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.
-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.
SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
--
--
-- Database: `ASI_07_08`
--
DROP DATABASE IF EXISTS ASI_07_08;
CREATE DATABASE ASI_07_08;
USE ASI_07_08;
-- --------------------------------------------------------
--
-- Table structure for table `A`
--
CREATE TABLE IF NOT EXISTS `A` (
  `Year` varchar(2) NOT NULL COMMENT '08 for ASI 2007_2008',
  `Block` varchar(2) NOT NULL COMMENT 'A for Block A',
  `DSL` varchar(6) NOT NULL,
  `PSL_No` varchar(5) NOT NULL,
  `Scheme_code` varchar(1) NOT NULL COMMENT 'Census-1, Sample-2',
  `Industrial_code_as_per_industrial_frame` varchar(4) NOT NULL COMMENT 'For details see the supporting documents',
  `Industrial_code_as_per_return` varchar(5) NOT NULL COMMENT 'For details see the supporting documents',
  `State_Code` varchar(2) NOT NULL COMMENT 'Please see the  supporting document for state codes',
  `District_code` varchar(2) NOT NULL COMMENT 'Please see the supporting documents for district codes',
  `Rural_Urban_code` varchar(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `RO_SRO_code` varchar(5) NOT NULL,
  `No_of_units` int(3) NOT NULL,
  `Status_of_Unit` int(2) NOT NULL COMMENT 'It gives a description of Operational status of the unit, i.e open closed etc.For details see the supporting documents',
  `manufacturing` int(3) NOT NULL COMMENT 'Number of Working Days in Manufacturing',
  `non_manufacturing` int(3) NOT NULL COMMENT 'Number of working days_non-manufacturing',
  `Number_of_working_days` int(3) NOT NULL COMMENT 'Number of Working Days(Total) Manufacturing and Non-Manufacturing',
  `Cost_of_Production` int(12) NOT NULL,
  `multiplier` decimal(4,4) NOT NULL,
  `filler` varchar(108) NOT NULL,
  PRIMARY KEY (`Block`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='For official use';

-- --------------------------------------------------------

--
-- Table structure for table `B`
--

CREATE TABLE IF NOT EXISTS `B` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for ASI 07_08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'B for Block B',
  `DSL` varchar(6) NOT NULL COMMENT 'BLOCK A, Item 1',
  `Type_of_organisation` int(2) NOT NULL COMMENT 'For detail see the supporting documents.',
  `Type_of_ownership` int(1) NOT NULL COMMENT 'Details of the codes are given in supporting documents.',
  `No_of_Units` int(4) NOT NULL COMMENT 'Total number of units the company has',
  `No_of_units_State` int(4) NOT NULL COMMENT 'How many units located in the same state',
  `Year_of_initial_production` int(4) NOT NULL,
  `Accounting_year_From` int(9) NOT NULL,
  `Accounting_year_To` int(9) NOT NULL,
  `No_of_months_of_operation` int(2) NOT NULL COMMENT 'Number of months of operation',
  `computerised_AC_system` int(1) NOT NULL COMMENT 'Yes-1,No-2',
  `ASI_data_in_Computer_Floppy` int(1) NOT NULL COMMENT 'Yes-1,No-2',
  `Padded_with_0_or_blank` varchar(131) NOT NULL,
  PRIMARY KEY (`BLOCK`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='FACTORY DETAIL';

-- --------------------------------------------------------

--
-- Table structure for table `C`
--

CREATE TABLE IF NOT EXISTS `C` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for ASI 2007_08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'C for Block C. This Block gives details of fixed assets.',
  `DSL` varchar(6) NOT NULL,
  `Serial` varchar(2) NOT NULL COMMENT 'Serial Number',
  `Opening` int(12) NOT NULL COMMENT 'Land,Building Plant &Machinery,Transport equipment, Computer equipment including software Pollution Control Equipment and Others and Capital work in progress.',
  `Due_to_revaluation` int(12) NOT NULL COMMENT 'Land,Building Plant &Machinery,Transport equipment, Computer equipment including software Pollution Control Equipment and Others and Capital work in progress.',
  `Actual_addition` int(12) NOT NULL COMMENT 'Land,Building Plant &Machinery,Transport equipment, Computer equipment including software Pollution Control Equipment and Others and Capital work in progress.',
  `Deduction_adjustment` int(12) NOT NULL COMMENT 'Land,Building Plant &Machinery,Transport equipment, Computer equipment including software Pollution Control Equipment and Others and Capital work in progress.',
  `Closing` int(12) NOT NULL COMMENT 'Summation of Opening as on, Due to revaluation, Actual Addition, Deduction & Adjustment during the year. This is in Gross Value.',
  `Up_to_year_beginning` int(12) NOT NULL,
  `Provided_during_the year` int(12) NOT NULL COMMENT 'Provided during the year',
  `Up_to_year_end` int(12) NOT NULL COMMENT 'Summation of Up to year beginning and Provid-ed during the year.',
  `Opening_as_on` int(12) NOT NULL COMMENT 'Net Value and it is Opening as on minus Up to year beginning.',
  `Closing_as_on` int(12) NOT NULL COMMENT 'Net Value and it is Closing as on minus Up to year end.',
  `Padded_with_0_or_blank` varchar(46) NOT NULL,
  PRIMARY KEY (`BLOCK`,`DSL`,`Serial`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='FIXED ASSETS';

-- --------------------------------------------------------

--
-- Table structure for table `D`
--

CREATE TABLE IF NOT EXISTS `D` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for year 2007-08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'D for Block D',
  `DSL` varchar(6) NOT NULL COMMENT 'BLOCK A, Item 1',
  `Serial_Number` int(2) NOT NULL COMMENT '(to be entered as printed in the schedule)',
  `Opening` int(12) NOT NULL COMMENT '(In Rupees)',
  `Closing` int(12) NOT NULL COMMENT 'In Rs',
  `Padded_with_0_or_blank` varchar(142) NOT NULL,
  PRIMARY KEY (`BLOCK`,`DSL`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='WORKING CAPITAL & LOANS';

-- --------------------------------------------------------

--
-- Table structure for table `E`
--

CREATE TABLE IF NOT EXISTS `E` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for Year 2007-08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'E for Block E',
  `DSL` varchar(6) NOT NULL COMMENT 'BLOCK A, Item 1',
  `Serial` varchar(2) NOT NULL COMMENT 'Serial Number',
  `Mandays_Worked` int(8) NOT NULL COMMENT 'Mandays Worked (Manufacturing)',
  `Manday_Worked` int(8) NOT NULL COMMENT 'Manday Worked (Non Manufacturing)',
  `Mandays_Worked_Total` int(10) NOT NULL COMMENT 'Mandays Worked (TOTAL)',
  `Average_No_persons_worked` int(8) NOT NULL COMMENT 'Average Number of persons worked',
  `No_of_mandays_paid` int(10) NOT NULL COMMENT 'No of mandays paid for',
  `Wages_salaries` int(12) NOT NULL COMMENT 'WAGES AND SALARIES are defined to include all remuneration in monetary terms and also payable more or less regularly in each pay period to workers as compensation for work done during the accounting year. It includes (a) direct wages and salary (i.e., bas',
  `Bonus` int(12) NOT NULL COMMENT 'Bonus (in Rs.)',
  `Provident_and_other_funds` int(12) NOT NULL COMMENT 'Contribution to  Provident Fund and other funds',
  `Workmen_Staff_Welfare_Expenses` int(12) NOT NULL COMMENT 'Workmen & Staff Welfare Expenses',
  `Padded_with_0_or_blank` varchar(74) NOT NULL COMMENT 'Padded with 0 or blank',
  PRIMARY KEY (`BLOCK`,`DSL`,`Serial`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT=' EMPLOYMENT AND LABOUR COST';

-- --------------------------------------------------------

--
-- Table structure for table `F`
--

CREATE TABLE IF NOT EXISTS `F` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for Year 2007-08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'F for Block F',
  `DSL` varchar(6) NOT NULL COMMENT 'BLOCK A, Item 1',
  `Work_done_by_others` int(12) NOT NULL,
  `Repair_maintenance_of_Building` int(12) NOT NULL COMMENT 'Repair & maintenance of Building',
  `Repair_maintenance_of_Plant` int(12) NOT NULL COMMENT 'Repair & maintenance of Plant & Machinery',
  `Repair_maintenance_of_Pollution` int(12) NOT NULL COMMENT 'Repair & maintenance of Pollution control equipment',
  `Repair_maintenance_of_Other` int(12) NOT NULL COMMENT 'Repair & maintenance of Other fixed assets',
  `Operating_expenses` int(12) NOT NULL,
  `Non_operating_expenses` int(12) NOT NULL,
  `Insurance_Charges` int(12) NOT NULL,
  `Rent_Paid` int(12) NOT NULL COMMENT 'Rent paid for Plant & Machinery and other Fixed assets',
  `Total_expenses` int(12) NOT NULL,
  `Rent_paid_for_Buildings` int(12) NOT NULL,
  `Rent` int(12) NOT NULL COMMENT 'Rent paid for land on lease or royalties on mines, quarries etc',
  `Interest_paid` int(12) NOT NULL,
  `Purchase_value` int(12) NOT NULL COMMENT 'Purchase value of goods sold in the same condition as purchased',
  PRIMARY KEY (`BLOCK`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='OTHER EXPENSES';

-- --------------------------------------------------------

--
-- Table structure for table `G`
--

CREATE TABLE IF NOT EXISTS `G` (
  `ASI` varchar(2) NOT NULL COMMENT '''08'' for Year 2007-08',
  `BLOCK` varchar(2) NOT NULL,
  `DSL` varchar(6) NOT NULL COMMENT 'BLOCK A, Item 1',
  `Income_services` int(12) NOT NULL COMMENT 'Income from services (industrial/non industrial including work done for others on materials supplied by them and sale value of waste left by the party)',
  `Variation` int(12) NOT NULL COMMENT 'Variation in stock of semi-finished goods',
  `Electricity_generated_and_sold` int(12) NOT NULL COMMENT 'Value in electricity generated and sold',
  `Value_own_Construction` int(12) NOT NULL COMMENT 'Value of own construction',
  `Net_balance` int(12) NOT NULL COMMENT 'Net balance if goods sold in the same condition as purchased',
  `Rent_received` int(12) NOT NULL COMMENT 'Rent received for Plant & Machinery and other fixed assets',
  `Total_receipts` int(12) NOT NULL COMMENT '(1 to 6)',
  `Rent_received_for_building` int(12) NOT NULL,
  `Rent_received_for_land` int(12) NOT NULL COMMENT 'Rent received for land on lease or royalties on mines, quarries',
  `Interest_received` int(12) NOT NULL,
  `Sale_value` int(12) NOT NULL COMMENT 'Sale value of goods sold in the same condition as purchased',
  `Padded_with_0_or_blank` varchar(36) NOT NULL,
  PRIMARY KEY (`BLOCK`,`DSL`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='OTHER INCOMES';

-- --------------------------------------------------------

--
-- Table structure for table `H`
--

CREATE TABLE IF NOT EXISTS `H` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for Year 2007-08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'H for Block H',
  `DSL` varchar(6) NOT NULL,
  `Serial` varchar(2) NOT NULL COMMENT 'Serial Number',
  `Item_code` varchar(5) NOT NULL COMMENT 'Item code (AISCC).Please see supporting documents for ASICC CODES',
  `Unit_of_quantity` int(3) NOT NULL COMMENT 'Unit of quantity (code)',
  `Quantity_consumed` decimal(11,3) NOT NULL COMMENT '(as 99999999999.999)',
  `Purchase_value` int(12) NOT NULL COMMENT '(In Rupees)',
  `Rate_per_unit` decimal(12,2) NOT NULL COMMENT '(In Rupees)',
  `Padded_with_0_or_blank` varchar(116) NOT NULL,
  PRIMARY KEY (`BLOCK`,`DSL`,`Serial`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='INPUT ITEMS (indigenous items consumed)';

-- --------------------------------------------------------

--
-- Table structure for table `I`
--

CREATE TABLE IF NOT EXISTS `I` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for Year 2007-08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'I for Block I',
  `DSL` varchar(6) NOT NULL,
  `Serial` varchar(2) NOT NULL COMMENT 'Serial Number',
  `Item_code` varchar(5) NOT NULL COMMENT 'Item code (ASICC). Please see supporting documents for ASICC CODES',
  `Unit_of_quantity` int(3) NOT NULL COMMENT 'Please see supporting documents',
  `Quantity_consumed` decimal(11,3) NOT NULL COMMENT '(as 999999999999.99)',
  `Purchase_value` int(12) NOT NULL COMMENT 'Purchase value at delivery (in Rs.)',
  `Rate_per_unit` decimal(12,2) NOT NULL COMMENT '(In Rupees)',
  `Padded_with_0_or_blank` varchar(116) NOT NULL,
  PRIMARY KEY (`BLOCK`,`DSL`,`Serial`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='INPUT ITEMS – directly imported items only (consumed) ';

-- --------------------------------------------------------

--
-- Table structure for table `J`
--

CREATE TABLE IF NOT EXISTS `J` (
  `ASI` varchar(2) NOT NULL COMMENT '08 for Year 2007-08',
  `BLOCK` varchar(2) NOT NULL COMMENT 'J for Block J',
  `DSL` varchar(6) NOT NULL,
  `Serial` varchar(2) NOT NULL COMMENT 'Serial Number',
  `Item_code` varchar(5) NOT NULL COMMENT 'Item code (ASICC). Please see the supporting documents',
  `Unit_of_quantity` int(3) NOT NULL COMMENT 'Unit of quantity (code). Please see the supporting documents for detail',
  `Quantity_manufactured` decimal(11,3) NOT NULL COMMENT '(as 99999999999.999)',
  `Quantity_sold` decimal(11,3) NOT NULL COMMENT '(as 99999999999.999)',
  `Gross_sale_value` int(12) NOT NULL COMMENT 'Gross sale value (Rs.). (including subsidy received)',
  `Excise_duty` int(12) NOT NULL,
  `Sales_Tax` int(12) NOT NULL,
  `Others` int(12) NOT NULL,
  `Total` int(12) NOT NULL COMMENT 'Excise duty + Sales Tax + Others',
  `Per_unit_net_sale_value` decimal(12,2) NOT NULL COMMENT '(Gross Sale Value - Total distributive expenses )/6',
  `Ex_factory_value_of_output` int(12) NOT NULL COMMENT '(Per unit net sale value) X 5',
  `Padded_with_0_or_blank` varchar(41) NOT NULL COMMENT 'Padded with 0 or blank',
  PRIMARY KEY (`BLOCK`,`DSL`,`Serial`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='PRODUCTS AND BY-PRODUCTS (manufactured by the unit)';

