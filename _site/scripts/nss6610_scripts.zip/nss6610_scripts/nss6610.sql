-- Copyright 2012 Centre for Economic Studies and Planning (CESP)

-- This script was written by Shreshtha Saraswat (shreshtha.saraswat at
-- gmail dot com) as part of an initiative directed by Vikas Rawal
-- (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
-- and ASI data. This initiative is supported by the CAS programme of
-- CESP.

-- This program is free software: you can redistribute it and/or modify
-- it under the terms of the GNU General Public License as published by
-- the Free Software Foundation, either version 3 of the License, or
-- (at your option) any later version.

-- This program is distributed in the hope that it will be useful,
-- but WITHOUT ANY WARRANTY; without even the implied warranty of
-- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
-- GNU General Public License for more details.

-- You should have received a copy of the GNU General Public License
-- along with this program.  If not, see <http://www.gnu.org/licenses/>.

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


--
-- Database: `NSS_66_10`
--
DROP DATABASE IF EXISTS NSS_66_10;
CREATE DATABASE NSS_66_10;
USE NSS_66_10;

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_01`
--

CREATE TABLE IF NOT EXISTS `LEVEL_01` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL COMMENT '66 Generated',
  `Schedule_Number` int(3) NOT NULL COMMENT '100 Generated',
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL COMMENT '0 Generated',
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '01 Generated',
  `Filler2` int(5) NOT NULL COMMENT '00000 Generated',
  `Informant_Serial_No` int(2) NOT NULL,
  `Response_Code` int(1) NOT NULL,
  `Survey_Code` int(1) NOT NULL COMMENT 'Original -1, Substitute -2, Casualty -3',
  `Substitution_Code` int(1) NOT NULL,
  `Date_of_Survey` int(6) NOT NULL COMMENT 'ddmmyy',
  `Date_of_Despatch` int(6) NOT NULL COMMENT 'ddmmyy',
  `Time_to_canvass_Sch10(mins.)` int(3) NOT NULL,
  `Time_to_canvass_Block9_of_Sch_10` int(3) NOT NULL,
  `Remark_in_block_10/11` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Remark_elsewhere` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(58) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Informant_Serial_No`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Blocks 1 & 2';


-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_02`
--

CREATE TABLE IF NOT EXISTS `LEVEL_02` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '02 Generated',
  `Filler2` int(5) NOT NULL COMMENT '00000 Generated',
  `Household_size` int(2) NOT NULL,
  `Principal_industry_NIC_2004_code` int(5) NOT NULL,
  `Principal_occupation_NC0_2004_code` int(3) NOT NULL,
  `Household type` int(1) NOT NULL,
  `Religion` int(1) NOT NULL,
  `Social_group` int(1) NOT NULL,
  `Land_owned` int(9) NOT NULL,
  `Land_possessed` int(9) NOT NULL,
  `Land_cultivated` int(9) NOT NULL,
  `NREG_job_card` int(1) NOT NULL,
  `Got_NREG_work` int(1) NOT NULL,
  `NREG_no_of_days_worked` int(3) NOT NULL,
  `NREG_mode_of_payment` int(1) NOT NULL,
  `saving_bank_held_by_any_member` int(1) NOT NULL,
  `saving_bank_no_of_a/c_in_the_hhd` int(2) NOT NULL,
  `recurring_deposit_account_held_by_any_member` int(1) NOT NULL,
  `recurring_deposit_account_number_of_accounts_in_the_household` int(2) NOT NULL,
  `MIS_held_by_any_member?` int(1) NOT NULL,
  `MIS_no_of_accounts_in_the_household` int(2) NOT NULL,
  `any_other_account_held_by_member` int(1) NOT NULL,
  `any_other_account_number_of_accounts_in_the_household` int(2) NOT NULL,
  `Money_order` int(1) NOT NULL,
  `Instant_money_order` int(1) NOT NULL,
  `International_monetary_transfer_service` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(22) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 3';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_03`
--

CREATE TABLE IF NOT EXISTS `LEVEL_03` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '03 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Serial_number_of_loan` int(2) NOT NULL,
  `Nature_of_loan` int(1) NOT NULL,
  `Source` int(1) NOT NULL,
  `Purpose` int(1) NOT NULL,
  `Amount_outstanding_including_interest` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(72) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number_of_loan`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 3.1';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_04`
--

CREATE TABLE IF NOT EXISTS `LEVEL_04` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_no` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '04 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Person_serial_no` int(2) NOT NULL,
  `Relation_to_head` int(1) NOT NULL,
  `Sex` int(1) NOT NULL COMMENT 'Male-1, Female-2',
  `Age` int(3) NOT NULL,
  `Marital_status` int(1) NOT NULL,
  `General_education` int(2) NOT NULL,
  `Technical_Education` int(2) NOT NULL,
  `Status_of_current_attendance` int(2) NOT NULL,
  `Type_of_institution` int(1) NOT NULL,
  `Registered_with_employment_exchange` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Vocational_training` int(1) NOT NULL,
  `Field_of_training` int(2) NOT NULL,
  `Duration_of_training` int(3) NOT NULL,
  `Source_Degree_etc_received` int(2) NOT NULL,
  `Beneficiary_of_the_scheme` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(60) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person_serial_no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 4';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_05`
--

CREATE TABLE IF NOT EXISTS `LEVEL_05` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '05 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Person Serial no` int(2) NOT NULL,
  `Age` int(3) NOT NULL,
  `Usual_principal_activity_Status` int(2) NOT NULL,
  `Usual_principal_activity_NIC_2004` int(5) NOT NULL,
  `Usual_principal_activity_NCO_2004` int(3) NOT NULL,
  `Whether_in subsidiary_activity?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Location_of_workspace` int(2) NOT NULL,
  `Enterprise_type` int(1) NOT NULL,
  `Enterprise_uses_electricity?` int(1) NOT NULL COMMENT 'Yes-1, No-2, Not Known-9',
  `No._of_workers_in_enterprise` int(1) NOT NULL,
  `Type_of job_contract` int(1) NOT NULL,
  `Eligible_for_paid_leave?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Social_security_benefits` int(1) NOT NULL,
  `Method_of_payment` int(1) NOT NULL,
  `Worked_under_given_specification?` int(1) NOT NULL,
  `Provider_credit/raw material/equipments` int(1) NOT NULL,
  `Number_of_outlets_of_disposal` int(1) NOT NULL,
  `Basis_of_payment` int(1) NOT NULL COMMENT 'Piece Rate-1, Contract Basis-2',
  `Type_of_specifications` int(1) NOT NULL COMMENT 'Written-1, Oral-2, Not Known-9',
  `Availabilty_of_work_during_last_365_days` int(1) NOT NULL,
  `Suitable_for_NCO_2004_code` int(3) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(51) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person Serial no`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 5.1';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_06`
--

CREATE TABLE IF NOT EXISTS `LEVEL_06` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '06 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Serial_number` int(2) NOT NULL,
  `Age` int(3) NOT NULL,
  `Usual_subsidiary_activity_status` int(2) NOT NULL,
  `Usual_subsidiary_activity_NIC_2004` int(5) NOT NULL,
  `Usual_subsidiary_activity_NCO_2004` int(3) NOT NULL,
  `Location_of_workspace` int(2) NOT NULL,
  `Enterprise_type` int(1) NOT NULL,
  `Enterprise_uses_electricity?` int(1) NOT NULL COMMENT 'Yes-1, No-2, Not Known-9',
  `Number_of_workers_in_enterprise` int(1) NOT NULL,
  `Type_of_job_contract` int(1) NOT NULL,
  `Eligible_for_paid_leave?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Social_security_benefits` int(1) NOT NULL,
  `Method_of payment` int(1) NOT NULL,
  `Worked_under_given_specification?` int(1) NOT NULL,
  `Provider_credit/raw_material/equipments` int(1) NOT NULL,
  `Number_of outlets_of_disposal` int(1) NOT NULL,
  `Basis_of_payments` int(1) NOT NULL COMMENT 'Piece Rate-1, Contract Basis-2',
  `Type_of_specifications` int(1) NOT NULL COMMENT 'Written-1, Oral-2, Not Known-9',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(56) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 5.2';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_07`
--

CREATE TABLE IF NOT EXISTS `LEVEL_07` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '07 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Person_Serial_Number` int(2) NOT NULL,
  `Age` int(3) NOT NULL,
  `Serial_number_of_activity` int(1) NOT NULL,
  `Status` int(2) NOT NULL,
  `NIC_2004_code` int(2) NOT NULL,
  `Operation` int(2) NOT NULL,
  `Intensity_7th_day` int(2) NOT NULL,
  `Intensity_6th_day` int(2) NOT NULL,
  `Intensity_5th_day` int(2) NOT NULL,
  `Intensity_4th_day` int(2) NOT NULL,
  `Intensity_3rd_day` int(2) NOT NULL,
  `Intensity_2nd_day` int(2) NOT NULL,
  `Intensity_1st_day` int(2) NOT NULL,
  `Total_number_of_days_in_each_activity` int(2) NOT NULL,
  `Wage_&_Salary_Earnings_Cash` int(8) NOT NULL,
  `Wage_&_Salary_Earnings_Kind` int(8) NOT NULL,
  `Wage_&_Salary_Earnings_Total` int(8) NOT NULL,
  `Mode_of_payment` int(2) NOT NULL,
  `Number_of_days_with_nominal_work` int(1) NOT NULL,
  `Current_weekly_activity_status` int(2) NOT NULL,
  `Current_weekly_activity_NIC_2004` int(5) NOT NULL,
  `Current_weekly_activity_NCO_2004` int(3) NOT NULL,
  `Unemployed_on_all_7_days` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(19) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block_5.3';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_08`
--

CREATE TABLE IF NOT EXISTS `LEVEL_08` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '08 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Serial_Number` int(2) NOT NULL,
  `Age` int(3) NOT NULL,
  `Duration_spell_of_unemployment` int(1) NOT NULL,
  `Whether_ever_worked` int(1) NOT NULL,
  `Last_employment_Duration` int(1) NOT NULL,
  `Last_employment_status` int(2) NOT NULL COMMENT 'Only codes 11-51 are applicable',
  `Last_employment_NIC_2004` int(2) NOT NULL,
  `Last_employment_NCO_2004` int(3) NOT NULL,
  `Reason_for_break_in_employment` int(1) NOT NULL,
  `Reason_for_quitting_the_job` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(68) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 6';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_09`
--

CREATE TABLE IF NOT EXISTS `LEVEL_09` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '09 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Serial_Number` int(2) NOT NULL,
  `Age` int(3) NOT NULL,
  `Usual_principal_activity_status` int(2) NOT NULL,
  `Usual_subsidiary_activity_status` int(2) NOT NULL,
  `Full_time/part_time` int(1) NOT NULL COMMENT 'Full time-1, Part time-2',
  `Worked_more_or_less_regularly` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `No._of_months_without_work` int(2) NOT NULL,
  `Available_for_work?` int(1) NOT NULL COMMENT 'Yes, on most days-1, Yes, on some days-2, No-3',
  `Made_any_efforts_to_get_work?` int(1) NOT NULL,
  `Employment_renumerative?` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Amount_considered_renumerative` int(1) NOT NULL,
  `Available_for_additional_work?` int(1) NOT NULL COMMENT 'Yes, on most days-1, Yes, on some days-2, No-3',
  `Reason1` int(1) NOT NULL,
  `Available_for_alternative_work?` int(1) NOT NULL COMMENT 'Yes, on most days-1, Yes, on some days-2, No-3',
  `Reason2` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(64) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 7.1';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_10`
--

CREATE TABLE IF NOT EXISTS `LEVEL_10` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '10 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Serial_Number` int(2) NOT NULL,
  `Age` int(3) NOT NULL,
  `Usual_principal_activity_status` int(2) NOT NULL,
  `Usual_subsidiary_activity_status` int(2) NOT NULL,
  `Union/Association` int(1) NOT NULL COMMENT 'Yes-1, No-2, Not Known-9',
  `Member_of_union/association` int(1) NOT NULL,
  `Nature_of_employment` int(1) NOT NULL COMMENT 'Permanent-1, Temporary-2',
  `Changed_work_activity_status` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Changed_last_activity_status` int(2) NOT NULL,
  `Changed_Industry` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Changed_last_Industry` int(2) NOT NULL,
  `Changed_Occupation` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Changed_Last_Occupation_code` int(2) NOT NULL,
  `Changed_Establishment` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Reason_for_last_change` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(62) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 7.2';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_11`
--

CREATE TABLE IF NOT EXISTS `LEVEL_11` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '11 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Person_Serial_Number` int(2) NOT NULL,
  `Age` int(3) NOT NULL,
  `Spend_time_on_domestic_duties` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Reason_thereof` int(1) NOT NULL COMMENT 'No other member to carry out the domestic duties-1, cannot afford hired help-2, for social and/or religious circumstances-3, others-9',
  `Reason_for_still_pursuing_domestic_duties` int(1) NOT NULL COMMENT 'Non-availability of work-1, By preference-2, Others-9',
  `Maintainence_of_kitchen_gardens_etc` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Household_Poultry` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Free_collection_of_fish_fruits_etc` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Free_collection_of_firewood_etc.` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Husking_of_paddy` int(1) NOT NULL,
  `Grinding_of_food_grains` int(1) NOT NULL,
  `Preparation_of_gur` int(1) NOT NULL,
  `Preservation_of_meat_and_wish` int(1) NOT NULL,
  `Making_baskets_and_mats` int(1) NOT NULL,
  `Preparation_of_cow_dung_as_fuel` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Sewing_weaving_tailoring_etc` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Tutoring_of_children` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Bring_water_from_outside_premises` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Rural_Bring_water_from_outside_village` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Rural_Distance` int(3) NOT NULL COMMENT 'If 1 in Previous Column, then distance in kilometres',
  `Willing_to_accept_work` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Nature_of_work_acceptable` int(1) NOT NULL,
  `Type_of_work_acceptable` int(1) NOT NULL,
  `Requisite_skill` int(1) NOT NULL COMMENT 'Yes-1, No-2',
  `Assistance_required` int(1) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(55) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Person_Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 8';

-- --------------------------------------------------------

--
-- Table structure for table `LEVEL_12`
--

CREATE TABLE IF NOT EXISTS `LEVEL_12` (
  `Round_and_Centre_code` int(3) NOT NULL,
  `FSU_Serial_No` int(5) NOT NULL,
  `Round` int(2) NOT NULL,
  `Schedule_Number` int(3) NOT NULL,
  `Sample` int(1) NOT NULL COMMENT 'Central-1, State-2',
  `Sector` int(1) NOT NULL COMMENT 'Rural-1, Urban-2',
  `State_Region` int(3) NOT NULL,
  `District` int(2) NOT NULL,
  `Stratum` int(2) NOT NULL,
  `Sub_Stratum_number` int(1) NOT NULL,
  `Filler1` int(1) NOT NULL,
  `Sub_Round` int(1) NOT NULL,
  `Sub_sample` int(1) NOT NULL,
  `FOD_Sub_Region` int(4) NOT NULL,
  `Hamlet_group_or_Sub_block_number` int(1) NOT NULL,
  `Second_stage_stratum_number` int(1) NOT NULL,
  `Sample_household_number` int(2) NOT NULL,
  `Level` int(2) NOT NULL COMMENT '12 Generated',
  `Filler2` int(3) NOT NULL COMMENT '000 Generated',
  `Serial_Number` int(2) NOT NULL,
  `Value_of_consumption_last_30_days` int(8) NOT NULL,
  `Value_of_consumption_last_365_days` int(8) NOT NULL,
  `Special_characters_for_OK_stamp` int(2) NOT NULL,
  `Blank` int(67) NOT NULL,
  `NSS` int(3) NOT NULL,
  `NSC` int(3) NOT NULL,
  `MLT` int(10) NOT NULL,
  `NSS_SR` int(3) NOT NULL,
  `NSC_SR` int(3) NOT NULL,
  `MLT_SR` int(10) NOT NULL,
  PRIMARY KEY (`FSU_Serial_No`,`Hamlet_group_or_Sub_block_number`,`Second_stage_stratum_number`,`Sample_household_number`,`Level`,`Serial_Number`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COMMENT='Block 9';
