# Copyright 2012 Centre for Economic Studies and Planning (CESP)
#
# This script was written by Shreshtha Saraswat (shreshtha.saraswat at
# gmail dot com) as part of an initiative directed by Vikas Rawal
# (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
# and ASI data. This initiative is supported by the CAS programme of
# CESP.
# 
# To run this, you need to specify below the ip address/hostname of
# the mysql server, the mysql username and mysql password.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /bin/sh
server=127.0.0.1 # ip address/hostname of the mysql server 
username="vikas"   # mysql user name
pass="redkonar"    # password of the mysql user
time_start=`date +%s`
echo "Scripts to read NSS 66th round Schedule 10 data called at `date`"
rm -Rf ../csv437856obstr
mkdir ../csv437856obstr
./level01.awk ../Data/LV661001.TXT
echo "Level 1 read at `date`"
./level02.awk ../Data/LV661002.TXT
echo "Level 2 read at `date`"
./level03.awk ../Data/LV661003.TXT
echo "Level 3 read at `date`"
./level04.awk ../Data/LV661004.TXT
echo "Level 4 read at `date`"
./level05.awk ../Data/LV661005.TXT
echo "Level 5 read at `date`"
./level06.awk ../Data/LV661006.TXT
echo "Level 6 read at `date`"
./level07.awk ../Data/LV661007.TXT
echo "Level 7 read at `date`"
./level08.awk ../Data/LV661008.TXT
echo "Level 8 read at `date`"
./level09.awk ../Data/LV661009.TXT
echo "Level 9 read at `date`"
./level10.awk ../Data/LV661010.TXT
echo "Level 10 read at `date`"
./level11.awk ../Data/LV661011.TXT
echo "Level 11 read at `date`"
./level12.awk ../Data/LV661012.TXT
echo "Level 12 read at `date`"
echo "Now creating MySQL database"
mysql --host=$server --user=$username --password=$pass < nss6610.sql
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_01.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_02.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_03.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_04.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_05.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_06.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_07.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_08.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_09.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_10.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_11.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_10 --local ../csv437856obstr/LEVEL_12.csv
echo "Mysql database created at `date`"
echo "Now cleaning up..."
rm -Rf ../csv437856obstr
time_end=`date +%s`
time_exec=`expr $(( $time_end - $time_start ))`
echo "The script took $time_exec seconds to finish."
