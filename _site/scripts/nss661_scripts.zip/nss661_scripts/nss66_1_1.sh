# Copyright 2012 Centre for Economic Studies and Planning (CESP)
#
# This script was written by Shreshtha Saraswat (shreshtha.saraswat at
# gmail dot com) as part of an initiative directed by Vikas Rawal
# (vikasrawal at gmail dot com) for preparing scripts for reading NSSO
# and ASI data. This initiative is supported by the CAS programme of
# CESP.
# 
# To run this, you need to specify below the ip address/hostname of
# the mysql server, the mysql username and mysql password.
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /bin/sh
server=127.0.0.1 # ip address/hostname of the mysql server 
username="USERNAME"   # mysql user name
pass="PASSWORD"    # password of the mysql user
time_start=`date +%s`
echo "Scripts to read NSS 66th round Schedule 1, Type 1 data called at `date`"
rm -Rf ../csv10abf
mkdir ../csv10abf
./level01.awk ../Data/LVL66S011.01.TXT
./level02.awk ../Data/LVL66S011.02.TXT
./level03.awk ../Data/LVL66S011.03.TXT
./level04.awk ../Data/LVL66S011.04.TXT
./level05.awk ../Data/LVL66S011.05.TXT
./level06.awk ../Data/LVL66S011.06.TXT
./level07.awk ../Data/LVL66S011.07.TXT
./level08.awk ../Data/LVL66S011.08.TXT
./level09.awk ../Data/LVL66S011.09.TXT
./level10.awk ../Data/LVL66S011.10.TXT
echo "Data parsed into csv files for each level at `date`"
mysql --host=$server --user=$username --password=$pass < nss661_type1.sql
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_01.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_02.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_03.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_04.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_05.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_06.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_07.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_08.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_09.csv
mysqlimport -u $username -p$pass --fields-terminated-by=, NSS_66_1_Type1 --local ../csv10abf/LEVEL_10.csv
echo "Mysql database created at `date`"
echo "Now cleaning up..."
rm -Rf ../csv10abf
time_end=`date +%s`
time_exec=`expr $(( $time_end - $time_start ))`
echo "The script took $time_exec seconds to finish."
